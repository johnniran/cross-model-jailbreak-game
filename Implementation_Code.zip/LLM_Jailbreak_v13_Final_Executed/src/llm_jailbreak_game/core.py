"""Version 13: theoretical finite-horizon game and continuous stage search.

Continuation values are piecewise linear on a finite state grid. Numerical
acceptance is a sampled test, never a proof of continuous-state equilibrium.
The primary method resolves actions at the current state. Linear action interpolation is a separate sensitivity policy.
"""

from __future__ import annotations

import itertools
import os
import sys
import json
import platform
import time
from dataclasses import dataclass, replace, asdict
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy
from scipy.optimize import root, least_squares, minimize, differential_evolution

try:
    from tqdm.auto import tqdm
except Exception:
    def tqdm(x, **kwargs):
        return x

try:
    from IPython.display import display as _display
except Exception:
    _display = None

try:
    from joblib import Parallel, delayed
except Exception:
    Parallel = None
    delayed = None

np.set_printoptions(precision=10, suppress=True)
pd.set_option("display.max_columns", 100)

# ------------------------------------------------------------
# 1. Model and numerical settings
# ------------------------------------------------------------
@dataclass(frozen=True)
class ModelParams:
    x0: float = 0.50
    theta: float = 0.60
    kappa_A: float = 0.50
    kappa_D: float = 0.50
    lam: float = 1.00
    rho: float = 0.50
    gamma: float = 0.95
    T: int = 10
    response_law: str = "rational"
    defender_loss: str = "quadratic"


@dataclass(frozen=True)
class NumericalSettings:
    dx: float = 0.05
    seed_step: float = 0.05
    strict_tol: float = 1e-9
    eps_ne: float = 1e-4
    optimizer_tol: float = 1e-10
    root_tol: float = 1e-10
    root_maxfev: int = 80
    cluster_tol: float = 1e-4
    selection_tie_tol: float = 1e-10
    global_audit_maxiter: int = 35
    global_audit_popsize: int = 8
    global_audit_seed: int = 20260928
    deep_audit_seeds: tuple = (20260928, 20260929, 20260930)
    deep_audit_maxiter: int = 100
    deep_audit_popsize: int = 15
    delta: float = 0.025
    delta_values: tuple = (0.01, 0.025, 0.05)
    audit_subdivisions: int = 2
    offgrid_subdivisions: int = 2
    policy_mode: str = "resolved"



BASELINE = ModelParams()
NUM = NumericalSettings()

LEVELS = {
    "x0": [0.10, 0.30, 0.50, 0.70, 0.90],
    "theta": [0.20, 0.40, 0.60, 0.80],
    "kappa_A": [0.25, 0.50, 1.00, 1.50],
    "kappa_D": [0.25, 0.50, 1.00, 1.50],
    "lam": [0.50, 1.00, 1.50, 2.00],
    "rho": [0.25, 0.50, 0.75, 1.00],
    "gamma": [0.80, 0.90, 0.95, 1.00],
    "T": [5, 10, 15, 20],
}

MATH_LABELS = {
    "x0": r"$x_0$",
    "theta": r"$\theta_{sj}$",
    "kappa_A": r"$\kappa_A$",
    "kappa_D": r"$\kappa_D$",
    "lam": r"$\lambda$",
    "rho": r"$\rho$",
    "gamma": r"$\gamma$",
    "T": r"$T$",
}


def validate_params(p: ModelParams) -> None:
    values = [p.x0,p.theta,p.kappa_A,p.kappa_D,p.lam,p.rho,p.gamma]
    if not all(np.isfinite(v) for v in values):
        raise ValueError("Model parameters must be finite.")
    if not (0<=p.x0<=1 and 0<=p.theta<=1):
        raise ValueError("x0 and theta must lie in [0,1].")
    if min(p.kappa_A,p.kappa_D,p.lam)<=0 or not (0<p.rho<=1 and 0<p.gamma<=1):
        raise ValueError("Costs and lambda must be positive; rho and gamma lie in (0,1].")
    if isinstance(p.T,bool) or not isinstance(p.T,(int,np.integer)) or p.T<1:
        raise ValueError("T must be a positive integer.")
    if p.response_law not in ("rational","exponential"):
        raise ValueError("Unknown response law.")
    if p.defender_loss not in ("quadratic","linear"):
        raise ValueError("Unknown defender loss.")


def validate_numerics(n: NumericalSettings) -> None:
    for step in (n.dx,n.seed_step):
        if not np.isfinite(step) or not 0<step<=1 or not np.isclose(1/step,round(1/step),atol=1e-12,rtol=0):
            raise ValueError("Grid spacing must be positive and divide [0,1].")
    for v in (n.strict_tol,n.eps_ne,n.delta,n.selection_tie_tol):
        if not np.isfinite(v) or v<0: raise ValueError("Tolerances must be finite and nonnegative.")
    for v in (n.optimizer_tol,n.root_tol,n.cluster_tol):
        if not np.isfinite(v) or v<=0: raise ValueError("Solver tolerances must be finite and positive.")
    for key, minimum in (("root_maxfev",10),("global_audit_maxiter",1),("global_audit_popsize",2),("deep_audit_maxiter",1),("deep_audit_popsize",2)):
        value=getattr(n,key)
        if isinstance(value,bool) or not isinstance(value,(int,np.integer)) or value<minimum:
            raise ValueError("Search budgets must be integers within their stated bounds.")
    for value in (n.global_audit_seed,*n.deep_audit_seeds):
        if isinstance(value,bool) or not isinstance(value,(int,np.integer)) or not 0<=value<2**32:
            raise ValueError("Search seeds must be unsigned 32-bit integers.")
    if n.policy_mode not in ("resolved","interpolated"):
        raise ValueError("policy_mode must be resolved or interpolated.")
    for v in (n.audit_subdivisions,n.offgrid_subdivisions):
        if isinstance(v,bool) or not isinstance(v,int) or v<1: raise ValueError("Audit subdivisions must be positive integers.")
    if not all(np.isfinite(v) and v>=0 for v in n.delta_values): raise ValueError("Invalid thresholds.")


def unit_grid(step: float) -> np.ndarray:
    n = int(round(1.0 / step))
    return np.linspace(0.0, 1.0, n + 1)


validate_params(BASELINE)
validate_numerics(NUM)


# ------------------------------------------------------------
# 2. Model equations
# ------------------------------------------------------------
def tau(a, d, p: ModelParams):
    if p.response_law == "rational":
        return p.theta * a / (1.0 + p.lam * d)
    return p.theta * a * np.exp(-p.lam * d)


def F(x, a, d, p: ModelParams):
    return (1.0 - p.rho) * x + p.rho * tau(a, d, p)


def U_A(x, a, d, p: ModelParams):
    xn = F(x, a, d, p)
    return xn - 0.5 * p.kappa_A * a**2


def U_D(x, a, d, p: ModelParams):
    xn = F(x, a, d, p)
    loss = xn**2 if p.defender_loss == "quadratic" else xn
    return -loss - 0.5 * p.kappa_D * d**2


# ------------------------------------------------------------
# 3. Stage game and continuously verified regret-bounded solution
# ------------------------------------------------------------
def stage_payoff_matrices(x, VA_next, VD_next, x_grid, a_grid, d_grid, p):
    A = a_grid[:, None]
    D = d_grid[None, :]
    x_next = F(x, A, D, p)
    stage_A = x_next - 0.5 * p.kappa_A * A**2
    stage_D = -(x_next**2 if p.defender_loss == "quadratic" else x_next) - 0.5 * p.kappa_D * D**2
    cont_A = np.interp(x_next.ravel(), x_grid, VA_next).reshape(x_next.shape)
    cont_D = np.interp(x_next.ravel(), x_grid, VD_next).reshape(x_next.shape)
    Q_A = stage_A + p.gamma * cont_A
    Q_D = stage_D + p.gamma * cont_D
    return x_next, Q_A, Q_D


def regret_matrices(Q_A: np.ndarray, Q_D: np.ndarray):
    regret_A = Q_A.max(axis=0, keepdims=True) - Q_A
    regret_D = Q_D.max(axis=1, keepdims=True) - Q_D
    return regret_A, regret_D, np.maximum(regret_A, regret_D)


def _value_slope(y: float, x_grid: np.ndarray, V: np.ndarray) -> float:
    """Slope of the piecewise-linear continuation value at an interior point."""
    k = int(np.searchsorted(x_grid, y, side="right") - 1)
    k = max(0, min(k, len(x_grid) - 2))
    return float((V[k + 1] - V[k]) / (x_grid[k + 1] - x_grid[k]))


def _Q_A_scalar(a: float, x: float, d: float, VA_next, x_grid, p: ModelParams) -> float:
    xn = float(F(x, a, d, p))
    return float(xn - 0.5 * p.kappa_A * a * a + p.gamma * np.interp(xn, x_grid, VA_next))


def _Q_D_scalar(d: float, x: float, a: float, VD_next, x_grid, p: ModelParams) -> float:
    xn = float(F(x, a, d, p))
    return float(U_D(x, a, d, p) + p.gamma * np.interp(xn, x_grid, VD_next))


def continuous_best_response_attacker(x, d, VA_next, x_grid, p: ModelParams):
    """Global one-dimensional best response over a in [0,1].

    Linear interpolation makes the continuation value piecewise linear in the
    next state. For fixed d, the next state is linear in a, so the objective is
    a concave quadratic within each interpolation segment. We therefore check
    all segment boundaries and the within-segment stationary point.
    """
    c = (1.0 - p.rho) * x
    s = p.rho * p.theta / (1.0 + p.lam * d) if p.response_law == "rational" else p.rho * p.theta * np.exp(-p.lam*d)
    if s <= 1e-15:
        return 0.0, _Q_A_scalar(0.0, x, d, VA_next, x_grid, p)

    breaks = [0.0, 1.0]
    for xv in x_grid[1:-1]:
        a = (float(xv) - c) / s
        if 1e-12 < a < 1.0 - 1e-12:
            breaks.append(float(a))
    breaks = np.array(sorted(set(round(v, 14) for v in breaks)), dtype=float)

    candidates = list(breaks)
    for lo, hi in zip(breaks[:-1], breaks[1:]):
        mid = 0.5 * (lo + hi)
        beta = _value_slope(c + s * mid, x_grid, VA_next)
        a_stat = s * (1.0 + p.gamma * beta) / p.kappa_A
        if lo < a_stat < hi:
            candidates.append(float(a_stat))

    candidates = np.unique(np.array(candidates, dtype=float))
    q = np.array([_Q_A_scalar(float(a), x, d, VA_next, x_grid, p) for a in candidates])
    qmax = float(q.max())
    # Smallest action breaks numerical ties reproducibly.
    idx = int(np.flatnonzero(q >= qmax - 1e-12)[0])
    return float(candidates[idx]), qmax


def continuous_best_response_defender(x, a, VD_next, x_grid, p: ModelParams):
    """Global one-dimensional best response over d in [0,1].

    For fixed a, the next state is c + q/(1+lambda*d). Within each linear
    interpolation segment the first-order condition is a quartic polynomial
    in z = 1+lambda*d. We evaluate all real stationary roots in each segment
    plus every segment boundary, giving a global check over the unit interval.
    """
    c = (1.0 - p.rho) * x
    qcoef = p.rho * p.theta * a
    if qcoef <= 1e-15:
        return 0.0, _Q_D_scalar(0.0, x, a, VD_next, x_grid, p)

    breaks = [0.0, 1.0]
    for xv in x_grid[1:-1]:
        den = float(xv) - c
        if den > 1e-14:
            d = (qcoef / den - 1.0) / p.lam if p.response_law == "rational" else -np.log(den / qcoef) / p.lam
            if 1e-12 < d < 1.0 - 1e-12:
                breaks.append(float(d))
    breaks = np.array(sorted(set(round(v, 14) for v in breaks)), dtype=float)

    candidates = list(breaks)
    for lo, hi in zip(breaks[:-1], breaks[1:]):
        mid = 0.5 * (lo + hi)
        y_mid = float(F(x,a,mid,p))
        beta = _value_slope(y_mid,x_grid,VD_next)
        if p.response_law == "exponential":
            # Partition at all zeros of the derivative's derivative, then
            # bracket every stationary root on its monotone intervals.
            from scipy.optimize import brentq
            def derivative(d):
                y=float(F(x,a,d,p)); yp=-p.lam*(y-c)
                loss_prime=2*y if p.defender_loss=="quadratic" else 1.0
                return (-loss_prime+p.gamma*beta)*yp-p.kappa_D*d
            B=(2*c if p.defender_loss=="quadratic" else 1.0)-p.gamma*beta
            coeff=[-4*p.lam**2*qcoef**2 if p.defender_loss=="quadratic" else 0.0,
                   -p.lam**2*qcoef*B,-p.kappa_D]
            critical=[lo,hi]
            for w in np.roots(np.trim_zeros(coeff,'f')):
                if abs(float(np.imag(w)))<1e-10 and float(np.real(w))>0:
                    dcrit=-np.log(float(np.real(w)))/p.lam
                    if lo<dcrit<hi:critical.append(float(dcrit))
            ds=np.array(sorted(critical))
            vals=np.array([derivative(d) for d in ds])
            for left,right,vl,vr in zip(ds[:-1],ds[1:],vals[:-1],vals[1:]):
                if vl*vr<0: candidates.append(float(brentq(derivative,left,right,xtol=1e-13)))
                if abs(vl)<1e-12: candidates.append(float(left))
        else:
            A = (2*c if p.defender_loss=="quadratic" else 1.0)-p.gamma*beta
            coeff = [-p.kappa_D,p.kappa_D,0.0,qcoef*p.lam**2*A,
                     2*qcoef**2*p.lam**2 if p.defender_loss=="quadratic" else 0.0]
            for r in np.roots(coeff):
                if abs(float(np.imag(r)))<=1e-8:
                    d=(float(np.real(r))-1)/p.lam
                    if lo+1e-10<d<hi-1e-10: candidates.append(float(d))

    candidates = np.unique(np.array(candidates, dtype=float))
    q = np.array([_Q_D_scalar(float(d), x, a, VD_next, x_grid, p) for d in candidates])
    qmax = float(q.max())
    idx = int(np.flatnonzero(q >= qmax - 1e-12)[0])
    return float(candidates[idx]), qmax


def continuous_pair_regret(x, a, d, VA_next, VD_next, x_grid, p: ModelParams):
    current_A = _Q_A_scalar(a, x, d, VA_next, x_grid, p)
    current_D = _Q_D_scalar(d, x, a, VD_next, x_grid, p)
    br_a, best_A = continuous_best_response_attacker(x, d, VA_next, x_grid, p)
    br_d, best_D = continuous_best_response_defender(x, a, VD_next, x_grid, p)
    rA = max(0.0, best_A - current_A)
    rD = max(0.0, best_D - current_D)
    return {
        "attacker_regret": float(rA),
        "defender_regret": float(rD),
        "max_regret": float(max(rA, rD)),
        "attacker_best_response": float(br_a),
        "defender_best_response": float(br_d),
    }


def _best_response_residual(z, x, VA_next, VD_next, x_grid, p: ModelParams):
    """Fixed-point residual for continuous best responses.

    The raw optimizer iterate may temporarily leave [0,1]. Actions used in the
    game are clipped to [0,1], while a boundary penalty pushes the raw iterate
    back to the feasible square. A zero residual therefore represents a
    mutual continuous best-response pair, including boundary equilibria.
    """
    raw = np.asarray(z, dtype=float)
    feasible = np.clip(raw, 0.0, 1.0)
    a, d = float(feasible[0]), float(feasible[1])
    br_a, _ = continuous_best_response_attacker(x, d, VA_next, x_grid, p)
    br_d, _ = continuous_best_response_defender(x, a, VD_next, x_grid, p)
    return np.array([a - br_a, d - br_d], dtype=float) + (raw - feasible)


def _initialization_seed_pairs(x, VA_next, VD_next, x_grid, p: ModelParams, n: NumericalSettings):
    """Return deterministic starting pairs for the continuous search.

    The initialization grid is used only to rank starting values. It is not an
    action constraint and is never used as the equilibrium acceptance test.
    """
    g = unit_grid(n.seed_step)
    _, Q_A, Q_D = stage_payoff_matrices(x, VA_next, VD_next, x_grid, g, g, p)
    _, _, max_grid_regret = regret_matrices(Q_A, Q_D)
    order = np.argsort(max_grid_regret, axis=None)
    starts = []
    # Two best grid locations provide local numerical guidance without
    # determining the accepted continuous action pair.
    for flat in order[:2]:
        i, j = np.unravel_index(int(flat), max_grid_regret.shape)
        starts.append((float(g[i]), float(g[j])))
    return starts, float(max_grid_regret.ravel()[order[0]])


def _deduplicate_starts(starts, tol=1e-10):
    out = []
    for s in starts:
        if s is None or len(s) != 2:
            continue
        arr = np.asarray(s, dtype=float)
        if not np.all(np.isfinite(arr)):
            continue
        a, d = np.clip(arr, 0.0, 1.0)
        pair = (float(a), float(d))
        if not any(max(abs(pair[0] - q[0]), abs(pair[1] - q[1])) <= tol for q in out):
            out.append(pair)
    return out


def _cluster_verified_candidates(candidates, tol: float):
    """Cluster numerically identical verified solutions in action space."""
    reps = []
    for c in sorted(candidates, key=lambda z: (z["max_regret"], z["a"], z["d"])):
        matched = False
        for k, r in enumerate(reps):
            if max(abs(c["a"] - r["a"]), abs(c["d"] - r["d"])) <= tol:
                matched = True
                if (c["max_regret"], c["a"], c["d"]) < (r["max_regret"], r["a"], r["d"]):
                    reps[k] = c
                break
        if not matched:
            reps.append(c)
    return reps


def _evaluate_continuous_candidate(x, a, d, VA_next, VD_next, x_grid, p, method, nfev=0):
    a = float(np.clip(a, 0.0, 1.0)); d = float(np.clip(d, 0.0, 1.0))
    c = continuous_pair_regret(x, a, d, VA_next, VD_next, x_grid, p)
    residual = _best_response_residual((a, d), x, VA_next, VD_next, x_grid, p)
    return {
        "a": a, "d": d,
        "attacker_regret": c["attacker_regret"],
        "defender_regret": c["defender_regret"],
        "max_regret": c["max_regret"],
        "attacker_best_response": c["attacker_best_response"],
        "defender_best_response": c["defender_best_response"],
        "br_residual_norm": float(np.max(np.abs(residual))),
        "method": str(method), "nfev": int(nfev),
    }


def _selection_key(candidate, rule: str):
    if rule == "min_regret":
        return (candidate["max_regret"], candidate["a"], candidate["d"])
    if rule == "low_a":
        return (candidate["a"], candidate["max_regret"], candidate["d"])
    if rule == "high_a":
        return (-candidate["a"], candidate["max_regret"], candidate["d"])
    if rule == "low_d":
        return (candidate["d"], candidate["max_regret"], candidate["a"])
    if rule == "high_d":
        return (-candidate["d"], candidate["max_regret"], candidate["a"])
    raise ValueError(f"Unknown equilibrium-selection rule: {rule}")


def solve_stage_game(x, VA_next, VD_next, x_grid, p, n: NumericalSettings,
                     warm_starts=(), selection_rule: str = "min_regret",
                     search_profile: str = "standard", allow_global_audit: bool = True):
    """Search the continuous action square for a verified epsilon equilibrium.

    Search order:
      1) deterministic multistart fixed-point roots of the continuous best-
         response map;
      2) bounded least-squares refinement if no root passes verification;
      3) direct Powell minimisation of maximum continuous unilateral regret;
      4) deterministic differential-evolution audit if the local search still
         fails. The global audit is a numerical search diagnostic, not a proof
         of non-existence when it fails.

    The initialization grid supplies starting values only. Accepted actions are
    continuous and every retained pair is checked against continuous unilateral
    best responses. ``search_profile='audit'`` adds a denser deterministic set
    of starts for equilibrium-selection diagnostics without changing the model,
    tolerance, or accepted action space.
    """
    seed_starts, seed_grid_min_regret = _initialization_seed_pairs(
        x, VA_next, VD_next, x_grid, p, n
    )
    fixed = [(0.50, 0.50), (1.00, 0.00), (0.00, 1.00)]
    if search_profile == "audit":
        fixed += [
            (0.00, 0.00), (1.00, 1.00), (0.00, 0.50), (0.50, 0.00),
            (1.00, 0.50), (0.50, 1.00), (0.25, 0.25), (0.25, 0.75),
            (0.75, 0.25), (0.75, 0.75),
        ]
    elif search_profile != "standard":
        raise ValueError("search_profile must be 'standard' or 'audit'.")
    starts = _deduplicate_starts(list(warm_starts) + seed_starts + fixed)

    verified = []
    diagnostics = []
    for s0 in starts:
        rr = root(
            lambda z: _best_response_residual(z, x, VA_next, VD_next, x_grid, p),
            np.asarray(s0, dtype=float), method="hybr",
            options={"xtol": n.root_tol, "maxfev": n.root_maxfev},
        )
        z = np.clip(np.asarray(rr.x, dtype=float), 0.0, 1.0)
        rec = _evaluate_continuous_candidate(
            x, z[0], z[1], VA_next, VD_next, x_grid, p,
            method="best_response_root", nfev=getattr(rr, "nfev", 0),
        )
        diagnostics.append(rec)
        if rec["max_regret"] <= n.eps_ne + n.optimizer_tol:
            verified.append(rec)

    if not verified:
        ls_starts = _deduplicate_starts(seed_starts[:2] + [(0.50, 0.50), (0.0, 0.0), (1.0, 1.0)])
        for s0 in ls_starts:
            ls = least_squares(
                lambda z: _best_response_residual(z, x, VA_next, VD_next, x_grid, p),
                np.asarray(s0, dtype=float), bounds=(0.0, 1.0),
                xtol=n.root_tol, ftol=n.root_tol, gtol=n.root_tol,
                max_nfev=max(100, n.root_maxfev),
            )
            rec = _evaluate_continuous_candidate(
                x, ls.x[0], ls.x[1], VA_next, VD_next, x_grid, p,
                method="bounded_least_squares", nfev=getattr(ls, "nfev", 0),
            )
            diagnostics.append(rec)
            if rec["max_regret"] <= n.eps_ne + n.optimizer_tol:
                verified.append(rec)

    if not verified:
        if diagnostics:
            best0 = min(diagnostics, key=lambda z: (z["max_regret"], z["a"], z["d"]))
            start0 = np.array([best0["a"], best0["d"]], dtype=float)
        else:
            start0 = np.array(seed_starts[0] if seed_starts else (0.5, 0.5), dtype=float)
        pw = minimize(
            lambda z: continuous_pair_regret(
                x, float(z[0]), float(z[1]), VA_next, VD_next, x_grid, p
            )["max_regret"],
            start0, method="Powell", bounds=((0.0, 1.0), (0.0, 1.0)),
            options={"xtol": n.root_tol, "ftol": n.root_tol, "maxiter": 150},
        )
        rec = _evaluate_continuous_candidate(
            x, pw.x[0], pw.x[1], VA_next, VD_next, x_grid, p,
            method="direct_regret_minimization", nfev=getattr(pw, "nfev", 0),
        )
        diagnostics.append(rec)
        if rec["max_regret"] <= n.eps_ne + n.optimizer_tol:
            verified.append(rec)

    global_audit_attempted = False
    if not verified and allow_global_audit:
        global_audit_attempted = True
        de = differential_evolution(
            lambda z: continuous_pair_regret(
                x, float(z[0]), float(z[1]), VA_next, VD_next, x_grid, p
            )["max_regret"],
            bounds=[(0.0, 1.0), (0.0, 1.0)],
            seed=n.global_audit_seed,
            maxiter=n.global_audit_maxiter,
            popsize=n.global_audit_popsize,
            tol=1e-8, polish=True, updating="immediate", workers=1,
        )
        rec = _evaluate_continuous_candidate(
            x, de.x[0], de.x[1], VA_next, VD_next, x_grid, p,
            method="global_regret_audit", nfev=getattr(de, "nfev", 0),
        )
        diagnostics.append(rec)
        if rec["max_regret"] <= n.eps_ne + n.optimizer_tol:
            verified.append(rec)

    if not verified:
        best = min(diagnostics, key=lambda z: (z["max_regret"], z["a"], z["d"]))
        return {
            "success": False,
            "diagnostic": {
                **best,
                "seed_grid_min_regret": seed_grid_min_regret,
                "n_starts": len(starts),
                "global_audit_attempted": global_audit_attempted,
            },
        }

    distinct = _cluster_verified_candidates(verified, n.cluster_tol)
    near_zero = _cluster_verified_candidates(
        [c for c in verified if c["max_regret"] <= n.strict_tol + n.optimizer_tol],
        n.cluster_tol,
    )
    # The primary rule preserves the near-zero-first convention used in the
    # main results. Alternative rules are diagnostics for the adopted epsilon
    # solution concept, so they select across all distinct verified epsilon
    # candidates rather than only the near-zero subset.
    if selection_rule == "min_regret":
        pool = near_zero if near_zero else distinct
        min_regret = min(c["max_regret"] for c in pool)
        pool2 = [c for c in pool if c["max_regret"] <= min_regret + n.selection_tie_tol]
        chosen = min(pool2, key=lambda z: (z["a"], z["d"]))
    else:
        pool = distinct
        chosen = min(pool, key=lambda z: _selection_key(z, selection_rule))

    a, d = chosen["a"], chosen["d"]
    QA = _Q_A_scalar(a, x, d, VA_next, x_grid, p)
    QD = _Q_D_scalar(d, x, a, VD_next, x_grid, p)
    xn = float(F(x, a, d, p))

    return {
        "success": True,
        "a": a, "d": d, "QA": float(QA), "QD": float(QD),
        "x_next": xn, "tau": float(tau(a, d, p)),
        "attacker_regret": chosen["attacker_regret"],
        "defender_regret": chosen["defender_regret"],
        "max_regret": chosen["max_regret"],
        "attacker_best_response": chosen["attacker_best_response"],
        "defender_best_response": chosen["defender_best_response"],
        "br_residual_norm": chosen["br_residual_norm"],
        "search_method": chosen["method"],
        "seed_grid_min_regret": seed_grid_min_regret,
        "n_starts": len(starts),
        "n_verified_candidates": len(verified),
        "n_distinct_solutions": len(distinct),
        "multiple_solutions": bool(len(distinct) > 1),
        "n_near_zero_solutions": len(near_zero),
        "multiple_near_zero_solutions": bool(len(near_zero) > 1),
        "strict_continuous_fixed_point": bool(chosen["max_regret"] <= n.strict_tol),
        "selection_rule": selection_rule,
        "global_audit_attempted": global_audit_attempted,
        "selected_from_near_zero_pool": bool(selection_rule == "min_regret" and len(near_zero) > 0),
    }


# ------------------------------------------------------------
# 4. Backward recursion and trajectories
# ------------------------------------------------------------
def solve_mpne(p: ModelParams, n: NumericalSettings,
               selection_rule: str = "min_regret",
               search_profile: str = "standard",
               allow_global_audit: bool = True):
    validate_params(p); validate_numerics(n)
    x_grid = unit_grid(n.dx)
    nx = len(x_grid)

    V_A = np.zeros((p.T + 1, nx)); V_D = np.zeros((p.T + 1, nx))
    policy_A = np.full((p.T, nx), np.nan); policy_D = np.full((p.T, nx), np.nan)
    regret = np.full((p.T, nx), np.nan)
    br_residual = np.full((p.T, nx), np.nan)
    seed_regret = np.full((p.T, nx), np.nan)
    n_solutions = np.zeros((p.T, nx), dtype=int)
    n_near_zero = np.zeros((p.T, nx), dtype=int)
    strict = np.zeros((p.T, nx), dtype=bool)
    global_audit = np.zeros((p.T, nx), dtype=bool)
    method = np.empty((p.T, nx), dtype=object)

    for t in range(p.T - 1, -1, -1):
        for ix, x in enumerate(x_grid):
            warm = []
            if ix > 0 and np.isfinite(policy_A[t, ix - 1]) and np.isfinite(policy_D[t, ix - 1]):
                warm.append((policy_A[t, ix - 1], policy_D[t, ix - 1]))
            if t < p.T - 1 and np.isfinite(policy_A[t + 1, ix]) and np.isfinite(policy_D[t + 1, ix]):
                warm.append((policy_A[t + 1, ix], policy_D[t + 1, ix]))

            res = solve_stage_game(
                float(x), V_A[t + 1], V_D[t + 1], x_grid, p, n,
                warm_starts=warm, selection_rule=selection_rule,
                search_profile=search_profile, allow_global_audit=allow_global_audit,
            )
            if not res["success"]:
                return {
                    "success": False, "fail_stage": t, "fail_state": float(x),
                    "fail_state_index": int(ix), "diagnostic": res["diagnostic"],
                    "x_grid": x_grid, "V_A": V_A, "V_D": V_D,
                    "policy_A": policy_A, "policy_D": policy_D,
                    "selection_rule": selection_rule, "search_profile": search_profile,
                }
            V_A[t, ix] = res["QA"]; V_D[t, ix] = res["QD"]
            policy_A[t, ix] = res["a"]; policy_D[t, ix] = res["d"]
            regret[t, ix] = res["max_regret"]
            br_residual[t, ix] = res["br_residual_norm"]
            seed_regret[t, ix] = res["seed_grid_min_regret"]
            n_solutions[t, ix] = res["n_distinct_solutions"]
            n_near_zero[t, ix] = res["n_near_zero_solutions"]
            strict[t, ix] = res["strict_continuous_fixed_point"]
            global_audit[t, ix] = res["global_audit_attempted"]
            method[t, ix] = res["search_method"]

    return {
        "success": True, "x_grid": x_grid,
        "V_A": V_A, "V_D": V_D, "policy_A": policy_A, "policy_D": policy_D,
        "regret": regret, "br_residual": br_residual,
        "seed_regret": seed_regret, "n_solutions": n_solutions,
        "n_near_zero_solutions": n_near_zero,
        "strict_mask": strict, "global_audit_mask": global_audit,
        "search_method": method, "selection_rule": selection_rule,
        "search_profile": search_profile, "policy_mode": n.policy_mode,
        "params": p, "numerics": n, "allow_global_audit": allow_global_audit,
    }


def interpolated_actions(solution: dict, t: int, x: float) -> tuple[float,float]:
    """Linear action interpolation, used only when explicitly declared."""
    return (float(np.interp(x,solution["x_grid"],solution["policy_A"][t])),
            float(np.interp(x,solution["x_grid"],solution["policy_D"][t])))


def policy_actions(solution: dict,t: int,x: float) -> tuple[float,float]:
    """One declared strategy, used by trajectories AND both audit types.

    Grid actions are authoritative. Off-grid actions are re-solved using the
    stored continuation values and an interpolated warm start. If no pair is
    accepted, use the recorded minimum-regret candidate solely to keep the
    diagnostic strategy defined; the regret check records the failure.
    This is not an accepted equilibrium action or an unreported fallback.
    """
    if solution.get("policy_mode","interpolated")=="interpolated":
        return interpolated_actions(solution,t,x)
    cache=solution.setdefault("_action_cache",{})
    stage=0 if solution.get("static_policy",False) else t
    key=(stage,float(x))
    if key in cache:return cache[key]
    grid=solution["x_grid"];ix=int(np.argmin(np.abs(grid-x)))
    if abs(float(grid[ix])-x)<=1e-12:
        pair=(float(solution["policy_A"][t,ix]),float(solution["policy_D"][t,ix]))
    else:
        res=solve_stage_game(float(x),solution["V_A"][stage+1],solution["V_D"][stage+1],grid,
            solution["params"],solution["numerics"],warm_starts=[interpolated_actions(solution,t,x)],
            selection_rule=solution.get("selection_rule","min_regret"),
            search_profile=solution.get("search_profile","standard"),
            allow_global_audit=solution.get("allow_global_audit",True))
        rec=res if res["success"] else res["diagnostic"]
        pair=(float(rec["a"]),float(rec["d"]))
        if not res["success"]:
            solution.setdefault("offgrid_search_failures",{})[key]=dict(rec)
    cache[key]=pair
    return pair


def trajectory(p: ModelParams, solution: dict) -> pd.DataFrame:
    x=float(p.x0); rows=[]
    for t in range(p.T):
        a,d=policy_actions(solution,t,x)
        xn=float(F(x,a,d,p)); weight=p.gamma**t
        rows.append({"t":t,"x_t":x,"a":a,"d":d,"tau":float(tau(a,d,p)),
                     "x_next":xn,"discount":weight,
                     "attacker_stage_utility":float(U_A(x,a,d,p)),
                     "defender_stage_utility":float(U_D(x,a,d,p)),
                     "attack_cost":0.5*p.kappa_A*a*a,
                     "defence_cost":0.5*p.kappa_D*d*d,
                     "defender_state_loss":xn*xn if p.defender_loss=="quadratic" else xn})
        x=xn
    return pd.DataFrame(rows)


def cumulative_outcomes(path: pd.DataFrame) -> dict:
    w=path["discount"]
    return {"x_T":float(path.x_next.iloc[-1]),
            "discounted_attacker_utility":float((w*path.attacker_stage_utility).sum()),
            "discounted_defender_utility":float((w*path.defender_stage_utility).sum()),
            "discounted_state_sum":float((w*path.x_next).sum()),
            "discounted_defender_state_loss":float((w*path.defender_state_loss).sum()),
            "discounted_attack_cost":float((w*path.attack_cost).sum()),
            "discounted_defence_cost":float((w*path.defence_cost).sum()),
            "mean_attack_effort":float(path.a.mean()),"mean_defence_effort":float(path.d.mean()),
            "undiscounted_state_sum":float(path.x_next.sum())}


def analytic_fixed_defence(p: ModelParams, n: NumericalSettings, d: float=0.0) -> dict:
    """Exact dynamic attacker response to a fixed defence level for either law."""
    validate_params(p);validate_numerics(n)
    if not np.isfinite(d) or not 0<=d<=1: raise ValueError("Fixed defence must lie in [0,1].")
    grid=unit_grid(n.dx); marginal=p.rho*float(tau(1.0,d,p))/p.kappa_A
    actions=[min(1.0,marginal*sum((p.gamma*(1-p.rho))**k for k in range(p.T-t))) for t in range(p.T)]
    return {"success":True,"x_grid":grid,
            "policy_A":np.repeat(np.array(actions)[:,None],len(grid),axis=1),
            "policy_D":np.full((p.T,len(grid)),d)}


def solve_no_defense(p: ModelParams,n: NumericalSettings) -> dict:
    """Numerical DP kept separate from the analytical regression formula."""
    validate_params(p);validate_numerics(n)
    grid=unit_grid(n.dx); value=np.zeros((p.T+1,len(grid))); policy=np.zeros((p.T,len(grid)))
    for t in range(p.T-1,-1,-1):
        for ix,x in enumerate(grid):
            policy[t,ix],value[t,ix]=continuous_best_response_attacker(float(x),0.0,value[t+1],grid,p)
    return {"success":True,"x_grid":grid,"V0":value,"policy_A":policy,
            "policy_D":np.zeros_like(policy)}


def evaluate_fixed_policy(p: ModelParams,solution: dict,grid: np.ndarray) -> tuple[np.ndarray,np.ndarray]:
    """Evaluate the declared strategy on one diagnostic state grid."""
    va=np.zeros((p.T+1,len(grid)));vd=np.zeros_like(va)
    for t in range(p.T-1,-1,-1):
        pairs=np.array([policy_actions(solution,t,float(x)) for x in grid])
        a,d=pairs[:,0],pairs[:,1]
        nxt=F(grid,a,d,p)
        va[t]=U_A(grid,a,d,p)+p.gamma*np.interp(nxt,grid,va[t+1])
        vd[t]=U_D(grid,a,d,p)+p.gamma*np.interp(nxt,grid,vd[t+1])
    return va,vd


def compute_policy_exploitability(p: ModelParams,n: NumericalSettings,solution: dict) -> dict:
    """Full remaining-policy deviations at every stage and diagnostic grid state.

    Evaluation and best responses use the SAME declared opponent policy and
    diagnostic grid. This remains an interpolation-based numerical diagnostic.
    Signed gains are exported as well; clipping must not hide evaluation error.
    """
    grid=unit_grid(n.dx/n.audit_subdivisions)
    eq_a,eq_d=evaluate_fixed_policy(p,solution,grid)
    br_a=np.zeros_like(eq_a);br_d=np.zeros_like(eq_d); rows=[]
    for t in range(p.T-1,-1,-1):
        for ix,x in enumerate(grid):
            a,d=policy_actions(solution,t,float(x))
            _,br_a[t,ix]=continuous_best_response_attacker(float(x),d,br_a[t+1],grid,p)
            _,br_d[t,ix]=continuous_best_response_defender(float(x),a,br_d[t+1],grid,p)
            ga=br_a[t,ix]-eq_a[t,ix];gd=br_d[t,ix]-eq_d[t,ix]
            rows.append({"t":t,"x":float(x),"signed_gain_A":ga,"signed_gain_D":gd,
                         "gain_A":max(0.,ga),"gain_D":max(0.,gd),
                         "max_gain":max(0.,ga,gd),
                         "stage_tolerance_sum":n.eps_ne*sum(p.gamma**k for k in range(p.T-t))})
    table=pd.DataFrame(rows).sort_values(["t","x"]).reset_index(drop=True)
    ia=float(np.interp(p.x0,grid,br_a[0])-np.interp(p.x0,grid,eq_a[0]))
    id_=float(np.interp(p.x0,grid,br_d[0])-np.interp(p.x0,grid,eq_d[0]))
    summary={"policy_audit_dx":float(n.dx/n.audit_subdivisions),
             "policy_initial_gain_A":max(0.,ia),"policy_initial_gain_D":max(0.,id_),
             "policy_initial_max_gain":max(0.,ia,id_),
             "policy_all_states_max_gain":float(table.max_gain.max()),
             "policy_min_signed_gain":float(min(table.signed_gain_A.min(),table.signed_gain_D.min())),
             "policy_initial_pass_1e4":bool(max(0.,ia,id_)<=1e-4+n.optimizer_tol),
             "policy_all_states_pass_discounted_stage_bound":bool((table.max_gain<=table.stage_tolerance_sum+n.optimizer_tol).all()),
             "policy_evaluation_A_x0":float(np.interp(p.x0,grid,eq_a[0])),
             "policy_evaluation_D_x0":float(np.interp(p.x0,grid,eq_d[0]))}
    return {"summary":summary,"points":table,"x_grid":grid,"value_A":eq_a,"value_D":eq_d}


def audit_stage_policy(p: ModelParams,n: NumericalSettings,solution: dict,path: pd.DataFrame,include_uniform: bool=True) -> pd.DataFrame:
    """Audit sampled grid/off-grid states and the actual deployed trajectory.

    Continuation values are the primary solver's interpolated values. This
    local residual is distinct from the full-policy audit above.
    """
    points=unit_grid(n.dx/n.offgrid_subdivisions) if include_uniform else [];rows=[]
    for t in range(p.T):
        stage=0 if solution.get("static_policy",False) else t
        for x in points:
            a,d=policy_actions(solution,t,float(x))
            r=continuous_pair_regret(float(x),a,d,solution["V_A"][stage+1],solution["V_D"][stage+1],solution["x_grid"],p)
            rows.append({"domain":"uniform_probe","t":t,"x":float(x),"a":a,"d":d,**r,
                         "on_solver_grid":bool(np.isclose(x/n.dx,round(x/n.dx),atol=1e-10,rtol=0)),
                         "pass_stage_tolerance":bool(r["max_regret"]<=n.eps_ne+n.optimizer_tol)})
        q=path.iloc[t];r=continuous_pair_regret(float(q.x_t),float(q.a),float(q.d),solution["V_A"][stage+1],solution["V_D"][stage+1],solution["x_grid"],p)
        rows.append({"domain":"deployed_path","t":t,"x":float(q.x_t),"a":float(q.a),"d":float(q.d),**r,
                     "on_solver_grid":bool(np.isclose(q.x_t/n.dx,round(q.x_t/n.dx),atol=1e-10,rtol=0)),
                     "pass_stage_tolerance":bool(r["max_regret"]<=n.eps_ne+n.optimizer_tol)})
    return pd.DataFrame(rows)


def myopic_policy(p: ModelParams,n: NumericalSettings) -> dict:
    result=solve_mpne(replace(p,T=1),n)
    if result["success"]:
        result["static_policy"]=True
        result["policy_A"]=np.repeat(result["policy_A"],p.T,axis=0)
        result["policy_D"]=np.repeat(result["policy_D"],p.T,axis=0)
    return result


def attacker_response_to_policy(p: ModelParams,n: NumericalSettings,defence_policy: dict) -> dict:
    """Fine-grid DP response to sampled myopic defence; actions interpolate.

    This benchmark is an approximation, not a claim of an exact response to
    the unsampled state-by-state myopic policy.
    """
    grid=unit_grid(n.dx/n.audit_subdivisions);v=np.zeros((p.T+1,len(grid)))
    a=np.zeros((p.T,len(grid)));d=np.zeros_like(a)
    for t in range(p.T-1,-1,-1):
        d[t]=[policy_actions(defence_policy,t,float(x))[1] for x in grid]
        for ix,x in enumerate(grid):
            a[t,ix],v[t,ix]=continuous_best_response_attacker(float(x),float(d[t,ix]),v[t+1],grid,p)
    return {"success":True,"x_grid":grid,"policy_A":a,"policy_D":d}


def compare_policies(p: ModelParams,n: NumericalSettings,dynamic: dict|None) -> tuple[pd.DataFrame,pd.DataFrame]:
    candidates={"no_defence_dynamic_attacker":analytic_fixed_defence(p,n,0.0)}
    if dynamic is not None and dynamic["success"]: candidates["dynamic_nash_"+dynamic.get("policy_mode","interpolated")]=dynamic
    myopic=myopic_policy(p,n)
    if myopic["success"]:
        candidates["myopic_mutual"]=myopic
        candidates["myopic_defender_dynamic_attacker"]=attacker_response_to_policy(p,n,myopic)
    for d in (0.25,0.50,0.75,1.00):
        candidates[f"fixed_defence_{d:.2f}_dynamic_attacker"]=analytic_fixed_defence(p,n,d)
    summaries=[];paths=[]
    no_defence=cumulative_outcomes(trajectory(p,candidates["no_defence_dynamic_attacker"]))
    for name,policy in candidates.items():
        tr=trajectory(p,policy);metrics=cumulative_outcomes(tr)
        summaries.append({"policy":name,**metrics,
                          "delta_x_T_vs_no_defence":no_defence["x_T"]-metrics["x_T"],
                          "defender_utility_difference_vs_no_defence":metrics["discounted_defender_utility"]-no_defence["discounted_defender_utility"],
                          "threshold_exceeded":bool(no_defence["x_T"]-metrics["x_T"]>n.delta)})
        tr.insert(0,"policy",name);paths.append(tr)
    if not myopic["success"]:
        summaries.append({"policy":"myopic_mutual","comparison_status":"solver_failed",
                          "failure_stage":myopic["fail_stage"],"failure_state":myopic["fail_state"]})
    return pd.DataFrame(summaries),pd.concat(paths,ignore_index=True)


def analytical_validation(p: ModelParams,n: NumericalSettings,solution: dict|None) -> pd.DataFrame:
    numeric=solve_no_defense(p,n);exact=analytic_fixed_defence(p,n)
    expected=trajectory(p,exact);actual=trajectory(p,numeric)
    error=float(np.max(np.abs(numeric["policy_A"]-exact["policy_A"])))
    rows=[{"check":"no_defence_action_formula","max_absolute_error":error,"tolerance":1e-10,"passed":error<=1e-10},
          {"check":"no_defence_terminal_formula","max_absolute_error":abs(float(actual.x_next.iloc[-1]-expected.x_next.iloc[-1])),"tolerance":1e-10,"passed":abs(float(actual.x_next.iloc[-1]-expected.x_next.iloc[-1]))<=1e-10}]
    states=np.linspace(0,1,11)[:,None,None];actions=np.linspace(0,1,11)[None,:,None];defences=np.linspace(0,1,11)[None,None,:]
    transitions=F(states,actions,defences,p)
    outside=max(0.,-float(transitions.min()),float(transitions.max())-1.)
    rows.append({"check":"sampled_state_bounds","max_absolute_error":outside,"tolerance":1e-12,"passed":outside<=1e-12})
    if solution is not None and solution["success"]:
        g=solution["x_grid"];a=solution["policy_A"][-1];d=solution["policy_D"][-1]
        formula=np.clip(p.rho*tau(np.ones_like(d),d,p)/p.kappa_A,0,1)
        # Approximate equilibrium actions need not equal exact best responses.
        err=float(np.max(np.abs(a-formula)))
        bound=np.sqrt(2*(n.eps_ne+n.optimizer_tol)/p.kappa_A)+1e-10
        rows.append({"check":"final_stage_attacker_action_bound","max_absolute_error":err,"tolerance":bound,"passed":err<=bound})
        derivative=[];kkt=[]
        for x,aa,dd in zip(g,a,d):
            q=float(F(x,aa,dd,p));qprime=(-p.rho*p.theta*aa*p.lam/(1+p.lam*dd)**2 if p.response_law=="rational" else -p.lam*(q-(1-p.rho)*x))
            der=-(2*q if p.defender_loss=="quadratic" else 1)*qprime-p.kappa_D*dd
            derivative.append(der)
            kkt.append(abs(der) if 1e-8<dd<1-1e-8 else max(0.,der) if dd<=1e-8 else max(0.,-der))
        rows.append({"check":"final_stage_defender_KKT_diagnostic","max_absolute_error":float(max(kkt)),"tolerance":np.nan,"passed":None})
    return pd.DataFrame(rows)


def run_configuration(p: ModelParams,n: NumericalSettings,keep_objects: bool=False,
                      selection_rule: str="min_regret",search_profile: str="standard",
                      allow_global_audit: bool=True,comparisons: bool=True,audit_scope: str="full") -> dict:
    validate_params(p);validate_numerics(n)
    if audit_scope not in ("full","grid_path"):raise ValueError("Unknown audit scope.")
    solution=solve_mpne(p,n,selection_rule,search_profile,allow_global_audit)
    nd=cumulative_outcomes(trajectory(p,analytic_fixed_defence(p,n)))
    summary={**asdict(p),"lambda":p.lam,"dx":n.dx,"eps_BR":n.eps_ne,"delta":n.delta,
             "selection_rule":selection_rule,"search_profile":search_profile,"audit_scope":audit_scope,
             "grid_accepted":bool(solution["success"]),"x_T_0":nd["x_T"],
             "policy_definition":n.policy_mode,
             "sampled_stage_verified":False,"path_stage_verified":False,
             "failure_stage":np.nan,"failure_state":np.nan,"failure_best_regret":np.nan}
    objects={"solution":solution}
    if not solution["success"]:
        summary.update(failure_stage=solution["fail_stage"],failure_state=solution["fail_state"],
                       failure_best_regret=solution["diagnostic"]["max_regret"],
                       failure_a=solution["diagnostic"]["a"],failure_d=solution["diagnostic"]["d"],
                       failure_method=solution["diagnostic"]["method"],
                       failure_global_search_attempted=solution["diagnostic"].get("global_audit_attempted",False),
                       failure_interpretation="search_did_not_find_an_accepted_pair_not_nonexistence")
    else:
        tr=trajectory(p,solution);audit=audit_stage_policy(p,n,solution,tr,include_uniform=audit_scope=="full")
        exploit=compute_policy_exploitability(p,n,solution) if audit_scope=="full" else {"summary":{},"points":pd.DataFrame(columns=["t","x","max_gain"])}
        metrics=cumulative_outcomes(tr)
        probe=audit[audit.domain=="uniform_probe"];pathaudit=audit[audit.domain=="deployed_path"]
        delta=nd["x_T"]-metrics["x_T"]
        summary.update({**metrics,**exploit["summary"],"x_T_star":metrics["x_T"],"delta_x_T":delta,
                        "relative_suppression":delta/nd["x_T"] if nd["x_T"]>0 else np.nan,
                        "threshold_exceeded":bool(delta>n.delta),
                        "defender_utility_difference_vs_no_defence":metrics["discounted_defender_utility"]-nd["discounted_defender_utility"],
                        "grid_max_stage_regret":float(solution["regret"].max()),
                        "sampled_max_stage_regret":float(probe.max_regret.max()) if len(probe) else np.nan,
                        "path_max_stage_regret":float(pathaudit.max_regret.max()),
                        "sampled_stage_verified":bool(probe.pass_stage_tolerance.all()) if len(probe) else None,
                        "path_stage_verified":bool(pathaudit.pass_stage_tolerance.all()),
                        "offgrid_probe_dx":n.dx/n.offgrid_subdivisions,
                        "n_probe_states_per_stage":len(unit_grid(n.dx/n.offgrid_subdivisions)) if len(probe) else 0,
                        "sampled_stage_failure_count":int((~probe.pass_stage_tolerance).sum()),
                        "strict_grid_share":float(solution["strict_mask"].mean()),
                        "epsilon_multiple_grid_share":float((solution["n_solutions"]>1).mean()),
                        "near_zero_multiple_grid_share":float((solution["n_near_zero_solutions"]>1).mean())})
        objects.update(trajectory=tr,stage_audit=audit,policy_audit=exploit)
    summary["primary_accepted"]=bool(summary["grid_accepted"] and summary["path_stage_verified"])
    if comparisons:
        objects["comparisons"],objects["comparison_paths"]=compare_policies(p,n,solution if solution["success"] else None)
    objects["analytical_checks"]=analytical_validation(p,n,solution if solution["success"] else None)
    if keep_objects: return {"summary":summary,**objects}
    return summary


def audit_failed_stage(p: ModelParams,n: NumericalSettings,solution: dict) -> pd.DataFrame:
    """Independent seeded searches of the first unresolved state-stage point."""
    if solution["success"]:return pd.DataFrame()
    t=solution["fail_stage"];x=solution["fail_state"];rows=[]
    for seed in n.deep_audit_seeds:
        result=differential_evolution(lambda z: continuous_pair_regret(x,float(z[0]),float(z[1]),solution["V_A"][t+1],solution["V_D"][t+1],solution["x_grid"],p)["max_regret"],
                                     [(0.,1.),(0.,1.)],seed=seed,maxiter=n.deep_audit_maxiter,popsize=n.deep_audit_popsize,
                                     tol=1e-10,polish=True,workers=1)
        r=continuous_pair_regret(x,float(result.x[0]),float(result.x[1]),solution["V_A"][t+1],solution["V_D"][t+1],solution["x_grid"],p)
        rows.append({**asdict(p),"dx":n.dx,"stage":t,"state":x,"seed":seed,"a":result.x[0],"d":result.x[1],
                     **r,"below_stage_tolerance":bool(r["max_regret"]<=n.eps_ne+n.optimizer_tol),
                     "interpretation":"point_search_only_no_proof_of_nonexistence"})
    return pd.DataFrame(rows)
