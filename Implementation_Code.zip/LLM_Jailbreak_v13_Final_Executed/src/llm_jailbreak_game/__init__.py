"""Theoretical jailbreak-transferability game; no empirical LLM experiments."""
from .core import ModelParams,NumericalSettings,BASELINE,NUM,tau,F,U_A,U_D,solve_mpne,run_configuration
__version__="13.0.0"
__all__=["ModelParams","NumericalSettings","BASELINE","NUM","tau","F","U_A","U_D","solve_mpne","run_configuration"]
