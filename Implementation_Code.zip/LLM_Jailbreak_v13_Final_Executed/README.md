# Version 13 final reproducibility package

This is a theoretical finite-horizon simultaneous game of aggregate attack and
defence effort around an assumed source–target language-model pair. It does not
query language models, measure attack success, or fit the parameters to data.

Version 13 restores current-state action solving as the primary strategy.
Version 12's interpolated-action strategy remains a separately labelled
sensitivity comparison. The same declared strategy is used for trajectories,
local stage checks and remaining-policy diagnostics.

## Results and scientific limits

Primary acceptance means that every solver-grid point and every realised-path
point meets the continuous-action stage-regret criterion against the stored
interpolated continuation values. It is not continuous-state equilibrium
coverage. The dynamic profile does not dominate every tested commitment policy in defender payoff. Midpoint probes and whole-policy deviation estimates have separate
flags. Some broader checks and finer-grid runs fail; no exact-equilibrium or
numerical-convergence claim is supplied.

The verified reference files are under `results/reference_v13`. See
`paper_metrics.json`, `output_verification.csv`, and `validation/FINAL_AUDIT.md`
for the actual counts and diagnostics. Failed configurations remain in every
planned design. A failed search is not a proof of equilibrium non-existence.

## Quick start

Use Python 3.11 or newer in a virtual environment. The delivered run used
Python 3.12.14 on Linux with the dependency versions pinned in `requirements.txt`.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install --no-deps -e .
python -m unittest discover -s tests -v
python scripts/verify_integrity.py
python scripts/verify_outputs.py --output results/reference_v13
python scripts/verify_paper_outputs.py --output results/reference_v13
```

On Windows, activate `.venv\Scripts\activate` instead. Windows locking is
implemented but was not tested in the delivered Linux run. The tests run
without LLM credentials. Cross-platform optimizer differences can affect
candidate discovery; compare acceptance flags as well as numerical outcomes.

To re-export the bounded manuscript figure and table set from the delivered raw
files, use:

```bash
python scripts/export_results.py --output results/reference_v13
```

This command overwrites derived paper files. File hashes should be checked
before re-exporting; export differences due to PDF metadata or fonts are not a
new solver experiment.

## Recompute the complete design

```bash
python scripts/run_analysis.py --phase all --output results/generated --jobs 8
python scripts/run_selection_audit.py --output results/generated --jobs 8
python scripts/verify_outputs.py --output results/generated
python scripts/export_results.py --output results/generated
```

Use `--jobs 1` for a smaller machine. `--resume` reuses only cases whose source,
parameters, numerical settings and stored file hashes match. Locked per-case
writes place the completion marker last. A completion marker means the case
files were written; numerical acceptance is a separate result.

The nine standard phases contain 1 reference case, 256 primary factorial cases,
33 one-at-a-time settings, 12 state-grid cases, 3 initialization cases, 768
auxiliary tolerance cases, 72 functional-form cases, 18 memoryless cases, and
6 policy-diagnostic cases. Selection checks then repeat every primary case
with discovered candidate multiplicity under five rules and one expanded
search profile. Repeated reference tuples across phases are intentional.

## Audit scopes

The reference, primary factorial, sensitivity, state-grid, initialization,
functional-form and policy-diagnostic phases use the full declared sampled
audit: solver states plus midpoint probes, realised paths, and approximate
whole-policy deviations. Tolerance, selection and memoryless phases use
`grid_path` scope. They do not run the broader state or whole-policy audits;
unperformed successful-case fields are null, not invented passes.

Whole-policy diagnostics evaluate the declared strategy on their own state
grid and compute a dynamic unilateral response against the same opponent
strategy. Evaluation and best-response values still interpolate next states.
A discounted sum of stage tolerances is a comparison scale, not a certified
error bound. `policy_initial_pass_1e4` tests a fixed reference tolerance of
0.0001, independently of auxiliary stage tolerances.

Off-grid actions are re-solved against the stored continuation arrays using an
interpolated warm start. The chosen pair is cached so all diagnostic callers
use the same strategy. If no pair is accepted, the minimum-regret candidate
keeps the diagnostic strategy defined and its failure appears in the stage
regret file. Grid actions are authoritative within a state distance of 1e-12.
The global-search option is propagated to off-grid solving. Failed grid
recursions have no defended terminal outcome.

## Compact paper set

`results/reference_v13/paper/main` contains three figures and three tables.
`paper/revised_supplementary` contains the three current manuscript tables
and the three-page Word copy. The supplementary figure remains in
`paper/supplementary`; its original four full audit tables are retained there
for the unchanged exporter and verifier. All figure rasters
include PNG previews at 300 dpi, independently rendered RGB TIFF files at
600 dpi with lossless LZW compression, and vector PDFs. Tables have CSV and Markdown
versions. `paper/MANUSCRIPT_OUTPUT_INDEX.json` supplies the current manuscript selection.
`paper/OUTPUT_INDEX.json` remains the original full-audit export index required
by the unchanged verification script. See `paper/revised_supplementary/README.md`
for the row selection and revised manuscript cross-references.

Figure 1 shows (a) attack and defence effort and (b) defended and no-defence
state paths, with both panel letters and both state lines. The interaction
heatmap contains acceptance counts, so no separate coverage heatmap is needed.
The histogram, cost heatmap, duplicate baseline plots and large per-case
plots are omitted from the manuscript presentation. Their underlying data
remain in raw case files and phase CSVs.

The Word correction guide is a separate deliverable. It gives complete
paragraph replacements, exact source anchors, equation moves and revised
captions. Its equations are editable native Word math, rather than images.

The proposed manuscript title is "A theoretical finite horizon game of attack
and defence effort for cross model jailbreak transfer in large language models".
This identifies the LLM application while retaining the theoretical scope.
Figure 3 uses the actual tested levels as horizontal ticks. Its unresolved
susceptibility level of 0.8 is labelled with text and has no plotted outcome.
The apparently flat initial-state panel has a small, nonzero range, reported
in Table 3. `Figure3_plot_records.json` records the actual exported plot lines
and axes; `verify_paper_outputs.py` compares them with independent calculations
from all 33 raw OAT cases and checks the TIFF metadata and compact tables.

## Layout

- `src/llm_jailbreak_game`: model, solver, declared strategy and audits.
- `scripts`: experiments, selection checks, output verification and export.
- `tests`: independent dense-action and analytical tests plus policy/checkpoint tests.
- `results/reference_v13/cases`: complete raw case records and file hashes.
- `results/reference_v13/*_results.csv`: complete planned phase rows.
- `documentation`: model assumptions and revision record.
- `notebooks`: executed overview of the delivered reference outputs.
- `validation`: test logs, integrity/output results and final critical audit.
- `reproducibility`: environment information and package file checksums.

The package prepares a reproducible GitHub release; it does not claim that a
public repository URL or permanent DOI already exists.
