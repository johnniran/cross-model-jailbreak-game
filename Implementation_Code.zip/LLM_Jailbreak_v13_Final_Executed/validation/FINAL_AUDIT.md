# Final critical implementation audit

Version 13 final snapshot was checked on 4 October 2026.

## Verified work

- 16 focused tests passed. These include 20001-point independent dense-action tests of both global one-dimensional best responses, analytical no-defence/final-stage checks, state/utility checks, declared-policy tests, integer/seed validation, corrupted-checkpoint rejection, the propagated global-search option, and repeated myopic stage audits.
- Output verification passed for 1674 completed cases. It checks case hashes and source signatures, complete experiment designs, raw/aggregate agreement, transitions, cumulative costs/payoffs, value recursions, numerical flags, no-defence formulas and recomputed path regrets.
- The standard design has 1169 cases; five selection rules cover all 101 detected-multiplicity cases, adding 505 cases. Common-cohort selection results use 97 cases.
- The 18 memoryless cases pass primary acceptance; maximum action difference across the boundary design is 6e-15, below 1e-6.
- The executed notebook reads this delivered snapshot and embeds the final Figure 1.

## Scientific outcome

Primary factorial acceptance is 251/256, with 249 passing all midpoint stage checks. Initial whole-policy diagnostic gain is at most 0.0001 in 241 primary-accepted cases.

Reference defended terminal state: 0.308326038541.
Reference no-defence terminal state: 0.462652343750.
Reference terminal suppression: 0.154326305209.
Reference initial remaining-policy diagnostic gain at spacing 0.025: 0.000990927392, above 0.0001.

The reference at primary state spacings 0.025 and 0.0125 remains unresolved. The reference whole-policy estimate changes with diagnostic resolution. The code records these failures. No continuous-state equilibrium or numerical-convergence claim is supported. The original manuscript already acknowledged exact-equilibrium and convergence limits; the correction guide retains that qualification.

In the reference policy comparison, fixed defence of 0.50 gives a higher defender payoff than the resolved dynamic profile. Mutual myopic play also gives a more favourable payoff and terminal state, but it changes attacker planning. The dynamic attacker response to sampled myopic defence is a different, approximate benchmark. No dominance claim for the dynamic profile is supported.

The OAT design accepts 32 of 33 settings. The highest susceptibility level is unresolved. Current-response weight has the largest range among initial state, current-response weight, discount factor and horizon. It does not have the largest range across all eight parameters: susceptibility has the largest accepted-level range, with that missing upper level. Ranges are not standardised importance indices.

## Mathematical and implementation assessment

The rational and alternative-response best-response calculations passed independent numerical comparisons. State invariance, utility accounting, fixed-defence formulas and the memoryless reduction agree with the specified equations. Two-player search remains heuristic; global one-dimensional best responses do not prove discovery of every two-player equilibrium.

Version 12 changed the off-grid strategy. Version 13 restores current-state resolving for the primary results and keeps action interpolation as a labelled sensitivity policy. The same strategy interface serves trajectories and audits. Stored grid actions are authoritative. Off-grid failed candidates keep the diagnostic policy defined and their local regret failures remain visible. Search control is propagated to off-grid queries.

Candidate sorting, near-zero-pool flags and input validation are corrected. Checkpoints are locked and completed last, with per-file hashes checked before reuse. The delivered snapshot contains only complete validated cases; incomplete staging directories and locks are excluded. The final verifier uses zero relative tolerance.

## Reporting set

Three main figures and three main tables; one supplementary figure and four supplementary tables. Figure 1 has (a) attack/defence effort and (b) defended/no-defence state paths. Repeated plots and large per-case presentation tables are omitted; all planned raw records remain available.

## Remaining contribution limits

The state, susceptibility, effort scales, persistence, response function and utility forms are assumptions. No LLM measurements or calibration are supplied. Empirical safeguard effectiveness, exact equilibrium existence/uniqueness and convergence remain unestablished. The work is a conditional theoretical simulation, with explicit comparisons and diagnostics, rather than a validated deployed LLM defence.

The supplied code is suitable for review and reproducibility of that scope. A Q1-journal decision still depends on the contribution and journal remit; correcting code does not resolve missing empirical evidence. The Word guide proposes published peer-reviewed sources only and removes the preprint entry.

## Final delivery and TIFF audit

All 16 focused tests and the 1674-case output verifier passed again. The solver
source signature remains 09cba560175ceb8a4df8e61397c5c2ac79a9a15a4941bc7ee8ca73a4501940d2.
The complete planned phases and the recorded numerical failures are retained.

The paper-output verifier passed for all 33 OAT cases, eight actual Figure 3
plot records, all seven numeric tables, and four independently rendered RGB
600-dpi LZW TIFF files. Its machine-readable results are in
results/reference_v13/paper_output_verification.json.

The OAT design has 32 accepted cases and one unresolved susceptibility case at
0.8. Each case varies one parameter and holds the rest at the reference. The
initial-state suppression range is 0.0002284232886267945, explaining its nearly
flat appearance on the common vertical scale. Figure 3 uses tested levels as
ticks and replaces its near-zero unresolved marker with explicit text; no
unresolved outcome is plotted. Figure 1 retains both panel labels and its
defended/no-defence state paths.

The title is revised to A theoretical finite horizon game of attack and defence
effort for cross model jailbreak transfer in large language models. A stale
Word-guide reference to cost means in Table S2 is corrected. Reference policy
costs are in Table 2; factorial costs remain in raw records. The Word equations
remain editable native OMML, not legacy MathType OLE objects.

The final release contains the README, pinned installation dependencies, source,
16 tests, experiment/export/verifier scripts, executed notebook, all 1674
completed case records, phase tables, compact paper outputs and validation
logs. Cache files, build metadata, staging files and locks are excluded. File
checksums, ZIP CRCs and content equality are checked when sealing the release.
The executed and GitHub packages have the same file contents. The combined
download contains that code folder and the revised Word guide. The standalone
TIFF bundle contains exactly the four retained scientific figures.

Scientific interpretation is unchanged: the reference fails the stronger
initial whole-policy gain criterion and some finer primary grids are
unresolved. Verification of file correctness does not establish continuous-state
equilibrium, numerical convergence or measured LLM safeguard effectiveness.
