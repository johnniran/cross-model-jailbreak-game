#!/usr/bin/env python3
"""Compatibility entry point for regenerating v13 tables and figures."""
from export_results import main
if __name__=='__main__':main()
