#!/usr/bin/env python3
"""Check raw case hashes, equations, flags, summaries and complete experiment designs."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from llm_jailbreak_game import core
from run_analysis import source_hash


def require(ok,message):
    if not ok:raise ValueError(message)


def close(a,b,atol=1e-11):return np.allclose(a,b,atol=atol,rtol=0,equal_nan=True)


def scalar_equal(a,b):
    if a is None or (isinstance(a,float) and np.isnan(a)):
        return b is None or (isinstance(b,float) and np.isnan(b))
    if isinstance(a,(bool,str)):return a==b
    return bool(close(a,b))


def path_metrics(path,p,name):
    require(len(path)==p.T and np.array_equal(path.t,np.arange(p.T)),name+': incorrect horizon or time index')
    require(close(path.x_t.iloc[0],p.x0,1e-13),name+': incorrect initial state')
    require(close(path.x_t.to_numpy()[1:],path.x_next.to_numpy()[:-1],1e-13),name+': path discontinuity')
    require(np.isfinite(path[['x_t','a','d','x_next']]).all().all(),name+': nonfinite path')
    require(((path[['a','d','x_t','x_next']]>=-1e-12)&(path[['a','d','x_t','x_next']]<=1+1e-12)).all().all(),name+': bounds')
    response=p.theta*path.a/(1+p.lam*path.d) if p.response_law=='rational' else p.theta*path.a*np.exp(-p.lam*path.d)
    xn=(1-p.rho)*path.x_t+p.rho*response
    ca=.5*p.kappa_A*path.a**2;cd=.5*p.kappa_D*path.d**2;loss=xn**2 if p.defender_loss=='quadratic' else xn;w=p.gamma**path.t
    for field,expected in [('tau',response),('x_next',xn),('discount',w),('attack_cost',ca),('defence_cost',cd),('defender_state_loss',loss),('attacker_stage_utility',xn-ca),('defender_stage_utility',-loss-cd)]:
        require(close(path[field],expected),name+': '+field+' mismatch')
    return {'x_T':float(xn.iloc[-1]),'discounted_attacker_utility':float((w*(xn-ca)).sum()),'discounted_defender_utility':float((w*(-loss-cd)).sum()),'discounted_state_sum':float((w*xn).sum()),'discounted_attack_cost':float((w*ca).sum()),'discounted_defence_cost':float((w*cd).sum()),'discounted_defender_state_loss':float((w*loss).sum()),'undiscounted_state_sum':float(xn.sum()),'mean_attack_effort':float(path.a.mean()),'mean_defence_effort':float(path.d.mean())}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,default=Path('results/reference_v13'));args=parser.parse_args();out=args.output.resolve()
    markers=sorted((out/'cases').glob('*/COMPLETE.json'));require(bool(markers),'No completed cases');summaries={};records=[];current_hash=source_hash()
    for marker in markers:
        folder=marker.parent;name=folder.name;complete=json.loads(marker.read_text());signature=json.loads((folder/'parameters.json').read_text())
        require(complete['signature']==signature,name+': signature mismatch');require(signature['source_sha256']==current_hash,name+': another code version')
        require('summary.json' in complete['file_sha256'],name+': incomplete hash manifest')
        for file,digest in complete['file_sha256'].items():require(hashlib.sha256((folder/file).read_bytes()).hexdigest()==digest,name+': corrupt '+file)
        p=core.ModelParams(**signature['params']);n=core.NumericalSettings(**signature['numerics']);core.validate_params(p);core.validate_numerics(n)
        s=json.loads((folder/'summary.json').read_text());summaries[name]=s
        for field,value in signature['params'].items():require(scalar_equal(value,s[field]),name+': parameter mismatch')
        require(s['policy_definition']==n.policy_mode and s['audit_scope']==signature['audit_scope'],name+': declared strategy mismatch')
        check=pd.read_csv(folder/'analytical_checks.csv').dropna(subset=['passed'])
        require(check.passed.astype(str).str.lower().eq('true').all(),name+': analytical test failed')
        # Independently expand the fixed-zero-defence analytical recursion.
        state=p.x0
        for t in range(p.T):
            a=min(1.,p.rho*p.theta/p.kappa_A*sum((p.gamma*(1-p.rho))**k for k in range(p.T-t)))
            state=(1-p.rho)*state+p.rho*p.theta*a
        require(close(state,s['x_T_0']),name+': no-defence formula mismatch')
        require(s['primary_accepted']==(s['grid_accepted'] and s['path_stage_verified']),name+': acceptance mismatch')
        if s['grid_accepted']:
            a=np.load(folder/'policies.npz',allow_pickle=False);grid=a['x_grid'];shape=(p.T,len(grid))
            for key in ['policy_A','policy_D','regret']:require(a[key].shape==shape and np.isfinite(a[key]).all(),name+': policy array mismatch')
            require(close(a['V_A'][-1],0) and close(a['V_D'][-1],0),name+': nonzero terminal value')
            for t in range(p.T):
                xn=(1-p.rho)*grid+p.rho*(p.theta*a['policy_A'][t]/(1+p.lam*a['policy_D'][t]) if p.response_law=='rational' else p.theta*a['policy_A'][t]*np.exp(-p.lam*a['policy_D'][t]))
                qa=xn-.5*p.kappa_A*a['policy_A'][t]**2+p.gamma*np.interp(xn,grid,a['V_A'][t+1])
                qd=-(xn**2 if p.defender_loss=='quadratic' else xn)-.5*p.kappa_D*a['policy_D'][t]**2+p.gamma*np.interp(xn,grid,a['V_D'][t+1])
                require(close(qa,a['V_A'][t]) and close(qd,a['V_D'][t]),name+': value recursion mismatch')
            require(close(a['regret'].max(),s['grid_max_stage_regret']),name+': grid regret maximum mismatch')
            require(a['regret'].max()<=n.eps_ne+n.optimizer_tol,name+': accepted grid exceeds tolerance')
            path=pd.read_csv(folder/'trajectory.csv');metrics=path_metrics(path,p,name)
            for key,value in metrics.items():require(close(value,s[key]),name+': cumulative '+key+' mismatch')
            require(close(s['x_T_0']-metrics['x_T'],s['delta_x_T']),name+': suppression mismatch')
            require(s['threshold_exceeded']==(s['delta_x_T']>n.delta),name+': threshold flag mismatch')
            audit=pd.read_csv(folder/'stage_audit.csv');pa=audit[audit.domain=='deployed_path'];probe=audit[audit.domain=='uniform_probe']
            require(len(pa)==p.T,name+': missing path audit')
            require(close(pa[['x','a','d']],path[['x_t','a','d']]),name+': audited path differs')
            require(np.isfinite(audit[['attacker_regret','defender_regret','max_regret']]).all().all(),name+': nonfinite audit')
            require(close(np.maximum(audit.attacker_regret,audit.defender_regret),audit.max_regret),name+': inconsistent regret maximum')
            require(np.array_equal((audit.max_regret<=n.eps_ne+n.optimizer_tol),audit.pass_stage_tolerance),name+': regret flags')
            require(bool(pa.pass_stage_tolerance.all())==s['path_stage_verified'],name+': path flag')
            require(close(pa.max_regret.max(),s['path_max_stage_regret']),name+': path regret maximum')
            if signature['audit_scope']=='full':
                require(len(probe)==p.T*len(core.unit_grid(n.dx/n.offgrid_subdivisions)),name+': incomplete probe design')
                require(bool(probe.pass_stage_tolerance.all())==s['sampled_stage_verified'],name+': probe flag')
                require(close(probe.max_regret.max(),s['sampled_max_stage_regret']),name+': probe regret maximum')
                pol=pd.read_csv(folder/'policy_audit.csv');require(len(pol)==p.T*len(core.unit_grid(n.dx/n.audit_subdivisions)),name+': incomplete policy audit')
                require(close(pol.max_gain.max(),s['policy_all_states_max_gain']),name+': policy gain maximum')
                require(s['policy_initial_pass_1e4']==(s['policy_initial_max_gain']<=1e-4+n.optimizer_tol),name+': initial whole-policy flag')
            else:require(len(probe)==0 and s['sampled_stage_verified'] is None,name+': unperformed audit must be null')
            if n.policy_mode=='interpolated':
                for row in path.itertuples():require(close(row.a,np.interp(row.x_t,grid,a['policy_A'][row.t])) and close(row.d,np.interp(row.x_t,grid,a['policy_D'][row.t])),name+': interpolated action mismatch')
            # Recompute all path regrets using the analytically tested global 1D best responses.
            for row in pa.itertuples():
                rec=core.continuous_pair_regret(row.x,row.a,row.d,a['V_A'][row.t+1],a['V_D'][row.t+1],grid,p)
                require(close(rec['max_regret'],row.max_regret),name+': recomputed path regret mismatch')
        else:
            require(s.get('delta_x_T') is None,name+': failed outcome unexpectedly filled')
            require(not s['primary_accepted'],name+': failed grid treated as accepted')
            require(s['failure_best_regret']>n.eps_ne+n.optimizer_tol,name+': failure below tolerance')
        if signature['comparisons']:
            cmp=pd.read_csv(folder/'comparisons.csv');paths=pd.read_csv(folder/'comparison_paths.csv')
            for policy,tr in paths.groupby('policy',sort=False):
                row=cmp[cmp.policy==policy].iloc[0];metrics=path_metrics(tr.reset_index(drop=True),p,name+'/'+policy)
                for key,value in metrics.items():require(close(value,row[key]),name+'/'+policy+': summary mismatch')
                require(close(state-metrics['x_T'],row.delta_x_T_vs_no_defence),name+'/'+policy+': benchmark mismatch')
        records.append({'case_id':name,'checks_passed':True,'primary_accepted':s['primary_accepted'],'audit_scope':s['audit_scope']})
    counts={'baseline':1,'factorial':256,'sensitivity':33,'grid':12,'initialization':3,'tolerance':768,'specification':72,'memoryless':18,'policy_refinement':6}
    for phase,count in counts.items():
        file=out/(phase+'_results.csv')
        if file.exists():
            df=pd.read_csv(file);require(len(df)==count and df.case_id.nunique()==count,phase+': incomplete/duplicated design')
            for row in df.to_dict('records'):
                require(row['case_id'] in summaries,phase+': missing raw case')
                for key,value in summaries[row['case_id']].items():require(scalar_equal(value,row[key]),phase+'/'+row['case_id']+': aggregate '+key+' mismatch')
    if (out/'factorial_results.csv').exists():
        f=pd.read_csv(out/'factorial_results.csv');require(f[['theta','lam','kappa_A','kappa_D']].drop_duplicates().shape[0]==256,'Factorial tuples duplicated')
    if (out/'selection_results.csv').exists():
        index=pd.read_csv(out/'selection_case_index.csv');df=pd.read_csv(out/'selection_results.csv')
        require(len(df)==5*len(index),'Incomplete selection design')
        for case in index.case_id:require(sum(df.case_id.str.startswith('selection_'+case+'_'))==5,case+': missing selection rule')
        for row in df.to_dict('records'):
            for key,value in summaries[row['case_id']].items():require(scalar_equal(value,row[key]),row['case_id']+': selection aggregate mismatch')
    pd.DataFrame(records).to_csv(out/'output_verification.csv',index=False)
    print(f'Output verification passed for {len(records)} cases. Numerical failures remain recorded.')

if __name__=='__main__':main()
