#!/usr/bin/env python3
"""Run reproducible v13 experiments with atomic per-case checkpoints."""
from __future__ import annotations
import argparse,json,itertools,time,os,sys,platform,hashlib,tempfile,shutil
from contextlib import contextmanager

@contextmanager
def case_lock(path):
    with open(path,"a+b") as handle:
        if os.name=="nt":
            import msvcrt
            handle.write(b"0");handle.flush();handle.seek(0)
            msvcrt.locking(handle.fileno(),msvcrt.LK_LOCK,1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(),fcntl.LOCK_EX)
        try:yield
        finally:
            if os.name=="nt":
                handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(handle.fileno(),fcntl.LOCK_UN)
from dataclasses import asdict,replace
from pathlib import Path
import numpy as np
import pandas as pd
from joblib import Parallel,delayed
from llm_jailbreak_game import core


def json_safe(value):
    if isinstance(value,dict):return {k:json_safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [json_safe(v) for v in value]
    if isinstance(value,np.generic):return json_safe(value.item())
    if isinstance(value,float) and not np.isfinite(value):return None
    return value


def source_hash():
    package=Path(core.__file__).parent
    h=hashlib.sha256()
    for path in sorted(package.glob('*.py')):h.update(path.name.encode());h.update(path.read_bytes())
    h.update(Path(__file__).read_bytes())
    return h.hexdigest()


def checkpoint_valid(folder,signature):
    marker=folder/'COMPLETE.json'
    if not marker.exists():return False
    try:
        prior=json.loads(marker.read_text())
        if prior.get('signature')!=signature:return False
        files=prior.get('file_sha256',{})
        if not files or 'summary.json' not in files:return False
        return all((folder/name).is_file() and hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest for name,digest in files.items())
    except (OSError,ValueError):return False


def execute_case(case_id,p,n,out,deep_audit=False,resume=False,selection_rule='min_regret',search_profile='standard'):
    locks=out/'locks';locks.mkdir(parents=True,exist_ok=True)
    with case_lock(locks/(case_id+'.lock')):
        return _execute_case(case_id,p,n,out,deep_audit,resume,selection_rule,search_profile)


def _execute_case(case_id,p,n,out,deep_audit=False,resume=False,selection_rule='min_regret',search_profile='standard'):
    folder=out/'cases'/case_id;folder.mkdir(parents=True,exist_ok=True)
    audit_scope="grid_path" if case_id.startswith(("eps_","selection_","memoryless_")) else "full"
    comparisons=case_id=="reference"
    signature={"audit_scope":audit_scope,"comparisons":comparisons,"source_sha256":source_hash(),"params":json_safe(asdict(p)),"numerics":json_safe(asdict(n)),
               "deep_audit":deep_audit,"selection_rule":selection_rule,"search_profile":search_profile}
    if resume and checkpoint_valid(folder,signature):
        return {'case_id':case_id,**json.loads((folder/'summary.json').read_text())}
    destination=folder
    (destination/'COMPLETE.json').unlink(missing_ok=True)
    folder=Path(tempfile.mkdtemp(prefix=case_id+'-',dir=out/'cases'))
    started=time.monotonic()
    result=core.run_configuration(p,n,keep_objects=True,selection_rule=selection_rule,search_profile=search_profile,audit_scope=audit_scope,comparisons=comparisons)
    summary=result['summary'];summary['elapsed_seconds']=time.monotonic()-started
    (folder/'summary.json').write_text(json.dumps(json_safe(summary),indent=2,allow_nan=False)+'\n')
    if comparisons:
        result['comparisons'].to_csv(folder/'comparisons.csv',index=False)
        result['comparison_paths'].to_csv(folder/'comparison_paths.csv',index=False)
    result['analytical_checks'].to_csv(folder/'analytical_checks.csv',index=False)
    solution=result['solution']
    if solution['success']:
        arrays={key:solution[key] for key in ('x_grid','V_A','V_D','policy_A','policy_D','regret','br_residual','n_solutions','n_near_zero_solutions')}
        np.savez_compressed(folder/'policies.npz',**arrays)
        result['trajectory'].to_csv(folder/'trajectory.csv',index=False)
        result['stage_audit'].to_csv(folder/'stage_audit.csv',index=False)
        result['policy_audit']['points'].to_csv(folder/'policy_audit.csv',index=False)
    else:
        np.savez_compressed(folder/'failed_recursion.npz',x_grid=solution['x_grid'],V_A=solution['V_A'],V_D=solution['V_D'],policy_A=solution['policy_A'],policy_D=solution['policy_D'])
        if deep_audit:core.audit_failed_stage(p,n,solution).to_csv(folder/'failure_seed_audit.csv',index=False)
    (folder/'parameters.json').write_text(json.dumps(signature,indent=2,allow_nan=False)+'\n')
    hashes={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in folder.iterdir() if path.is_file()}
    for prior in destination.iterdir():
        if prior.is_file() and prior.name not in hashes:prior.unlink()
    for path in folder.iterdir():path.replace(destination/path.name)
    folder.rmdir()
    temporary=destination/'COMPLETE.tmp'
    temporary.write_text(json.dumps({'signature':signature,'success':True,'file_sha256':hashes},indent=2)+'\n')
    temporary.replace(destination/'COMPLETE.json')
    print(f"{case_id}: grid={summary['grid_accepted']} sampled={summary['sampled_stage_verified']} path={summary['path_stage_verified']} ({summary['elapsed_seconds']:.1f}s)",flush=True)
    return {'case_id':case_id,**summary}


def factorial_cases(n):
    cases=[]
    for i,(theta,lam,ka,kd) in enumerate(itertools.product(core.LEVELS['theta'],core.LEVELS['lam'],core.LEVELS['kappa_A'],core.LEVELS['kappa_D'])):
        cases.append((f'factorial_{i:03d}',replace(core.BASELINE,theta=theta,lam=lam,kappa_A=ka,kappa_D=kd),n))
    return cases


def plan(phase):
    n=core.NUM
    if phase=='baseline':return [('reference',core.BASELINE,n)]
    if phase=='factorial':return factorial_cases(n)
    if phase=='sensitivity':
        return [(f'oat_{key}_{i:02d}',replace(core.BASELINE,**{key:value}),n) for key,values in core.LEVELS.items() for i,value in enumerate(values)]
    if phase=='grid':
        # Declared before seeing v13 results; include difficult high-theta cases.
        params=[('reference',core.BASELINE),('high_theta_low_lambda',replace(core.BASELINE,theta=.8,lam=.5)),
                ('high_theta_high_lambda',replace(core.BASELINE,theta=.8,lam=2.))]
        return [(f'grid_{name}_{dx:g}',p,replace(n,dx=dx)) for name,p in params for dx in (.1,.05,.025,.0125)]
    if phase=='initialization':return [(f'seeds_{h:g}',core.BASELINE,replace(n,seed_step=h)) for h in (.1,.05,.025)]
    if phase=='tolerance':
        return [(f'eps_{eps:.0e}_{name}',p,replace(n,eps_ne=eps)) for eps in (5e-5,2e-4,5e-4) for name,p,_ in factorial_cases(n)]
    if phase=='specification':
        cases=[]
        for law,loss in [('exponential','quadratic'),('rational','linear')]:
            for i,(theta,lam,ka,kd) in enumerate(itertools.product((.2,.6,.8),(.5,1.,2.),(.25,.5),( .25,.5))):
                cases.append((f'spec_{law}_{loss}_{i:03d}',replace(core.BASELINE,theta=theta,lam=lam,kappa_A=ka,kappa_D=kd,response_law=law,defender_loss=loss),n))
        return cases
    if phase=='memoryless':
        return [(f'memoryless_{i:02d}',replace(core.BASELINE,rho=1.,x0=x,gamma=g,T=t),n) for i,(x,g,t) in enumerate(itertools.product((.1,.5,.9),(.8,.95,1.),(5,10)))]
    if phase=='policy_refinement':return [(f'policy_audit_{mode}_{sub}',core.BASELINE,replace(n,audit_subdivisions=sub,policy_mode=mode)) for mode in ('resolved','interpolated') for sub in (1,2,4)]
    raise ValueError(phase)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path('results/generated'))
    parser.add_argument('--jobs',type=int,default=1)
    parser.add_argument('--phase',choices=['all','baseline','factorial','sensitivity','grid','initialization','tolerance','specification','memoryless','policy_refinement'],default='all')
    parser.add_argument('--resume',action='store_true',help='Reuse only checkpoints matching code and all settings.')
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    phases=['baseline','factorial','sensitivity','grid','initialization','tolerance','specification','memoryless','policy_refinement'] if args.phase=='all' else [args.phase]
    begin=time.monotonic()
    for phase in phases:
        cases=plan(phase);print(f'START {phase}: {len(cases)} cases',flush=True)
        rows=Parallel(n_jobs=args.jobs,backend='loky',inner_max_num_threads=1)(delayed(execute_case)(name,p,n,out,phase in ('factorial','grid'),args.resume) for name,p,n in cases)
        pd.DataFrame(rows).to_csv(out/f'{phase}_results.csv',index=False)
        print(f'COMPLETE {phase}',flush=True)
    import importlib.metadata
    packages={name:importlib.metadata.version(name) for name in ['numpy','pandas','scipy','matplotlib','joblib']}
    metadata={'version':'13.0.0','python':sys.version,'platform':platform.platform(),'packages':packages,
              'source_sha256':source_hash(),'phases_executed_in_this_invocation':phases,'elapsed_seconds':time.monotonic()-begin,
              'policy_definition':'resolve actions off-grid against stored continuation values; interpolation is a separate sensitivity policy',
              'primary_parameters':asdict(core.BASELINE),'primary_numerics':json_safe(asdict(core.NUM)),
              'scope':'theoretical simulation; no empirical LLM measurements',
              'limitation':'All verification is finite-grid/interpolation based; no continuous-state equilibrium proof or convergence claim.'}
    (out/'environment_and_settings.json').write_text(json.dumps(metadata,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':main()
