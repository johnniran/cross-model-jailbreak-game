#!/usr/bin/env python3
"""Verify the delivered file checksums; no solver run is required."""
import hashlib
from pathlib import Path


def main():
    root=Path(__file__).resolve().parents[1]
    manifest=root/'reproducibility/SHA256SUMS.txt';count=0
    for line in manifest.read_text().splitlines():
        digest,name=line.split('  ',1);path=(root/name).resolve()
        if not path.is_relative_to(root.resolve()):raise ValueError('Invalid manifest path.')
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise ValueError(f'Checksum mismatch: {name}')
        count+=1
    print(f'Integrity verification passed for {count} files.')


if __name__=='__main__':main()
