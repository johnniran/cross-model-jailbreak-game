#!/usr/bin/env python3
"""Independently check Figure 3 plot records, compact tables and TIFF metadata."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image


def require(condition, message):
    if not condition:
        raise ValueError(message)


def numeric(actual, expected, message):
    require(np.isclose(float(actual), float(expected), atol=1e-12, rtol=0, equal_nan=True), message)


def flag(value):
    return str(value).lower() == 'true'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path('results/reference_v13'))
    args = parser.parse_args()
    out = args.output.resolve()
    paper = out / 'paper'
    levels = {
        'x0': [.1, .3, .5, .7, .9], 'theta': [.2, .4, .6, .8],
        'kappa_A': [.25, .5, 1., 1.5], 'kappa_D': [.25, .5, 1., 1.5],
        'lam': [.5, 1., 1.5, 2.], 'rho': [.25, .5, .75, 1.],
        'gamma': [.8, .9, .95, 1.], 'T': [5, 10, 15, 20],
    }
    reference = json.loads((out / 'cases/reference/parameters.json').read_text())['params']
    oat = pd.read_csv(out / 'sensitivity_results.csv')
    require(len(oat) == 33 and oat.case_id.nunique() == 33, 'Incomplete OAT design')
    records = json.loads((paper / 'main/Figure3_plot_records.json').read_text())
    require(len(records) == 8, 'Figure 3 must contain eight panels')
    ranges = pd.read_csv(paper / 'main/Table3_sensitivity_ranges.csv').set_index('parameter')
    accepted_count = 0
    failures = []
    widths = []
    for i, ((key, planned), panel) in enumerate(zip(levels.items(), records)):
        require(panel['panel'] == chr(97+i) and panel['parameter'] == key, 'Incorrect panel order')
        frame = oat[oat.case_id.str.startswith('oat_'+key+'_')].sort_values(key)
        actual = frame[key].tolist()
        require(actual == planned == panel['x'] == panel['xticks'], key+': incorrect levels or ticks')
        require(len(panel['y']) == len(planned), key+': incorrect point count')
        valid_values = []
        missing = []
        for row, plotted in zip(frame.to_dict('records'), panel['y']):
            folder = out / 'cases' / row['case_id']
            params = json.loads((folder / 'parameters.json').read_text())['params']
            expected = dict(reference)
            expected[key] = row[key]
            require(params == expected, row['case_id']+': more than one parameter changed')
            summary = json.loads((folder / 'summary.json').read_text())
            require(bool(row['primary_accepted']) == summary['primary_accepted'], 'OAT flag mismatch')
            if not summary['primary_accepted']:
                require(plotted is None, 'An unresolved case was plotted as an outcome')
                missing.append(row[key])
                failures.append({'case':row['case_id'], 'parameter':key, 'level':row[key]})
                continue
            path = pd.read_csv(folder / 'trajectory.csv')
            defended = float(path.x_next.iloc[-1])
            state = float(params['x0'])
            for t in range(int(params['T'])):
                action = min(1., params['rho']*params['theta']/params['kappa_A'] *
                             sum((params['gamma']*(1-params['rho']))**k for k in range(int(params['T'])-t)))
                state = (1-params['rho'])*state + params['rho']*params['theta']*action
            suppression = state-defended
            require(np.isclose(plotted,suppression,atol=1e-12,rtol=0), 'Plotted value differs from independent path calculation')
            require(np.isclose(plotted,summary['delta_x_T'],atol=1e-13,rtol=0), 'Plotted value differs from raw summary')
            valid_values.append(plotted)
            accepted_count += 1
        require(panel['unresolved_levels'] == missing, 'Incorrect unresolved annotation')
        require(panel['threshold'] == .025, 'Incorrect descriptive threshold')
        require(panel['ylim'] == records[0]['ylim'], 'Unequal Figure 3 vertical scales')
        r = ranges.loc[key]
        require(int(r.tested_levels) == len(planned) and int(r.accepted_levels) == len(valid_values), 'Table 3 denominator mismatch')
        for actual_value, expected_value in [(r.min_suppression,min(valid_values)),(r.max_suppression,max(valid_values)),(r['range'],max(valid_values)-min(valid_values))]:
            require(np.isclose(actual_value,expected_value,atol=1e-13,rtol=0), 'Table 3 range mismatch')
        widths.append({'parameter':key,'accepted_range':max(valid_values)-min(valid_values)})
    require(accepted_count == 32 and failures == [{'case':'oat_theta_03','parameter':'theta','level':.8}], 'Unexpected OAT acceptance design')
    index = json.loads((paper / 'OUTPUT_INDEX.json').read_text())
    expected_counts = {'main_tables':3,'main_figures':3,'supplementary_tables':4,'supplementary_figures':1}
    tiffs = []
    for group, count in expected_counts.items():
        require(len(index[group]) == count, 'Incorrect compact output count')
        directory = paper / ('main' if group.startswith('main') else 'supplementary')
        for item in index[group]:
            if group.endswith('tables'):
                table = pd.read_csv(directory / (item['name']+'.csv'))
                require(len(table) == item['rows'], 'Incorrect table row count')
                require((directory / (item['name']+'.md')).is_file(), 'Missing readable table')
                continue
            for extension in ['png','pdf','tif']:
                require((directory / (item['name']+'.'+extension)).is_file(), 'Missing figure format')
            require(item['formats'] == ['png','pdf','tif'] and item['tiff_dpi'] == 600, 'Incorrect figure index metadata')
            with Image.open(directory / (item['name']+'.tif')) as im:
                im.load()
                require(im.format == 'TIFF' and im.mode == 'RGB', 'Incorrect TIFF format or colour mode')
                require(im.n_frames == 1, 'Unexpected multi-page TIFF')
                dpi = im.info.get('dpi')
                require(dpi is not None and np.allclose(dpi,[600,600],atol=1e-6,rtol=0), 'Incorrect TIFF resolution')
                require(int(im.tag_v2[259]) == 5, 'TIFF is not lossless LZW')
                size = im.size
            with Image.open(directory / (item['name']+'.png')) as preview:
                require(all(high >= low*1.95 for high,low in zip(size,preview.size)), 'TIFF was not independently rendered at higher resolution')
            tiffs.append({'figure':item['name'],'pixels':list(size),'dpi':[float(value) for value in dpi],'mode':'RGB','compression':'LZW'})
    source = pd.read_csv(out / 'cases/reference/comparisons.csv')
    comparison = pd.read_csv(paper / 'main/Table2_reference_policy_comparisons.csv')
    require(comparison.policy.tolist() == source.policy.tolist(), 'Policy comparison order mismatch')
    for column in comparison.columns[1:]:
        require(np.allclose(comparison[column],source[column],atol=1e-12,rtol=0), 'Policy table differs from raw comparisons')
    primary = pd.read_csv(out / 'factorial_results.csv')
    accepted = primary[primary.primary_accepted]
    table1 = pd.read_csv(paper / 'main/Table1_factorial_summary.csv').set_index('Measure').Value
    expected1 = {
        'Tested configurations':len(primary), 'Grid and path accepted':len(accepted),
        'Acceptance coverage (%)':100*len(accepted)/len(primary),
        'Mean terminal suppression':accepted.delta_x_T.mean(),
        'Median terminal suppression':accepted.delta_x_T.median(),
        'Minimum terminal suppression':accepted.delta_x_T.min(),
        'Maximum terminal suppression':accepted.delta_x_T.max(),
        'Above the terminal threshold':int((accepted.delta_x_T>.025).sum()),
        'Threshold exceedance (%)':100*(accepted.delta_x_T>.025).mean(),
        'Sampled stage checks passed':int(primary.sampled_stage_verified.sum()),
        'Whole-policy initial gain at most 0.0001':int((primary.primary_accepted & primary.policy_initial_pass_1e4).sum()),
    }
    require(set(table1.index) == set(expected1), 'Table 1 measures mismatch')
    for label,value in expected1.items():numeric(table1[label],value,'Table 1: '+label)
    settings = json.loads((out / 'cases/reference/parameters.json').read_text())
    table_s1 = pd.read_csv(paper / 'supplementary/TableS1_model_and_numerics.csv')
    for row in table_s1.itertuples():
        original = settings['params' if row.group == 'Model' else 'numerics'][row.setting]
        if isinstance(original,str):require(row.reference == original,'Table S1 setting mismatch')
        else:numeric(row.reference,original,'Table S1 numerical setting mismatch')
    table_s2 = pd.read_csv(paper / 'supplementary/TableS2_conditional_factorial.csv')
    for row in table_s2.itertuples():
        tested = primary[primary[row.parameter] == row.level]
        cohort = tested[tested.primary_accepted]
        for actual_value,expected_value in [(row.tested,len(tested)),(row.accepted,len(cohort)),(row.mean_suppression,cohort.delta_x_T.mean()),(row.threshold_exceedance,(cohort.delta_x_T>.025).mean())]:
            numeric(actual_value,expected_value,'Table S2 conditional summary mismatch')
    table_s3 = pd.read_csv(paper / 'supplementary/TableS3_numerical_checks.csv')
    tolerance = pd.read_csv(out / 'tolerance_results.csv')
    for row in table_s3.to_dict('records'):
        if row['panel'] == 'tolerance':
            tested = tolerance[tolerance.eps_BR == float(row['setting'].split('=')[1])]
            cohort = tested[tested.primary_accepted]
            for actual_value,expected_value in [(row['tested'],len(tested)),(row['accepted'],len(cohort)),(row['terminal_suppression'],cohort.delta_x_T.mean()),(row['TER'],(cohort.delta_x_T>.025).mean())]:
                numeric(actual_value,expected_value,'Table S3 tolerance mismatch')
            require(row['sampled_stage_pass'] == 'not run','Table S3 claims an unperformed audit')
            continue
        summary = json.loads((out / 'cases' / row['case'] / 'summary.json').read_text())
        require(flag(row['accepted']) == summary['primary_accepted'] and flag(row['sampled_stage_pass']) == summary['sampled_stage_verified'],'Table S3 acceptance mismatch')
        for column,field in [('terminal_suppression','delta_x_T'),('grid_max_regret','grid_max_stage_regret'),('initial_policy_gain','policy_initial_max_gain'),('path_max_regret','path_max_stage_regret')]:
            expected = summary.get(field) if summary['grid_accepted'] else None
            numeric(row[column],np.nan if expected is None else expected,'Table S3 raw case mismatch')
    table_s4 = pd.read_csv(paper / 'supplementary/TableS4_assumptions_and_failures.csv')
    selection = pd.read_csv(out / 'selection_results.csv')
    selection['primary_case'] = selection.case_id.str.extract(r'^selection_(factorial_\d+)_')[0]
    common = set(selection.primary_case)
    for rule in selection.selection_rule.unique():
        common &= set(selection[(selection.selection_rule == rule) & selection.primary_accepted].primary_case)
    specification = pd.read_csv(out / 'specification_results.csv')
    for row in table_s4.to_dict('records'):
        if row['panel'] == 'threshold':
            for actual_value,expected_value in [(row['tested'],len(primary)),(row['accepted'],len(accepted)),(row['mean_suppression'],accepted.delta_x_T.mean()),(row['TER'],(accepted.delta_x_T>float(row['setting'])).mean())]:
                numeric(actual_value,expected_value,'Table S4 threshold mismatch')
        elif row['panel'] == 'selection':
            tested = selection[selection.selection_rule == row['setting']]
            cohort = tested[tested.primary_case.isin(common)]
            for actual_value,expected_value in [(row['tested'],len(tested)),(row['accepted'],int(tested.primary_accepted.sum())),(row['common_cohort'],len(common)),(row['mean_suppression'],cohort.delta_x_T.mean()),(row['TER'],(cohort.delta_x_T>.025).mean())]:
                numeric(actual_value,expected_value,'Table S4 selection mismatch')
        elif row['panel'] == 'specification':
            law,loss = row['setting'].split(' / ')
            tested = specification[(specification.response_law == law) & (specification.defender_loss == loss)]
            alternate_values,primary_values = [],[]
            for alt in tested[tested.primary_accepted].to_dict('records'):
                matched = accepted
                for key in ['theta','lam','kappa_A','kappa_D']:matched = matched[matched[key] == alt[key]]
                if len(matched):
                    require(len(matched) == 1,'Duplicate functional-form comparison tuple')
                    alternate_values.append(alt['delta_x_T']);primary_values.append(float(matched.delta_x_T.iloc[0]))
            for actual_value,expected_value in [(row['tested'],len(tested)),(row['accepted'],int(tested.primary_accepted.sum())),(row['common_cohort'],len(alternate_values)),(row['mean_suppression'],np.mean(alternate_values)),(row['matched_primary_mean'],np.mean(primary_values)),(row['TER'],np.mean(np.array(alternate_values)>.025))]:
                numeric(actual_value,expected_value,'Table S4 functional-form comparison mismatch')
        else:
            raw = primary[primary.case_id == row['setting']].iloc[0]
            require(not raw.primary_accepted,'Table S4 failure is accepted')
            for column,field in [('theta','theta'),('lambda','lam'),('kappa_A','kappa_A'),('kappa_D','kappa_D'),('stage','failure_stage'),('state','failure_state'),('best_regret','failure_best_regret')]:
                numeric(row[column],raw[field],'Table S4 failure details mismatch')
    result = {'status':'passed','oat_cases':33,'oat_accepted':accepted_count,'unresolved':failures,
              'all_eight_plot_panels_match_raw_paths':True,'other_parameters_held_at_reference':True,
              'common_vertical_scale':True,'ticks_match_tested_levels':True,'ranges':widths,
              'compact_counts':expected_counts,'all_seven_table_values_checked':True,'tiffs':tiffs}
    (out / 'paper_output_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Paper output verification passed: 33 OAT cases, 8 plot panels, 7 tables and 4 RGB 600-dpi LZW TIFF figures.')


if __name__ == '__main__':
    main()
