#!/usr/bin/env python3
"""Verify the v13 reference outputs; raw numerical failures are retained."""
from verify_outputs import main
if __name__=='__main__':main()
