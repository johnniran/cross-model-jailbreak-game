#!/usr/bin/env python3
"""Check selection rules for every primary case with candidate multiplicity."""
import argparse
from pathlib import Path
from dataclasses import replace
import pandas as pd
from joblib import Parallel,delayed
from llm_jailbreak_game import core
from run_analysis import execute_case


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=Path('results/generated'))
    p.add_argument('--jobs',type=int,default=1)
    p.add_argument('--resume',action='store_true')
    args=p.parse_args();out=args.output.resolve()
    primary=pd.read_csv(out/'factorial_results.csv')
    eligible=primary[(primary.grid_accepted==True)&(primary.epsilon_multiple_grid_share>0)].sort_values('case_id')
    tasks=[]
    for row in eligible.itertuples():
        params=replace(core.BASELINE,theta=row.theta,lam=row.lam,kappa_A=row.kappa_A,kappa_D=row.kappa_D)
        for rule in ('min_regret','low_a','high_a','low_d','high_d'):
            tasks.append((f'selection_{row.case_id}_{rule}',params,rule))
    rows=Parallel(n_jobs=args.jobs,backend='loky',inner_max_num_threads=1)(delayed(execute_case)(case,p,core.NUM,out,False,args.resume,rule,'audit') for case,p,rule in tasks)
    eligible.to_csv(out/'selection_case_index.csv',index=False)
    pd.DataFrame(rows).to_csv(out/'selection_results.csv',index=False)
    print(f'Checked {len(eligible)} primary cases and {len(tasks)} rule/search combinations.')


if __name__=='__main__':main()
