#!/usr/bin/env python3
"""Compatibility entry point; v13 full design is the default in run_analysis."""
from run_analysis import main
if __name__=='__main__':main()
