#!/usr/bin/env python3
"""Export the bounded paper set: three main tables/figures and four tables/one figure in the supplement."""
import argparse,json,io
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from llm_jailbreak_game import core


def safe(v):
    if isinstance(v,dict):return {k:safe(x) for k,x in v.items()}
    if isinstance(v,list):return [safe(x) for x in v]
    if isinstance(v,np.generic):return safe(v.item())
    if isinstance(v,float) and not np.isfinite(v):return None
    return v


def markdown(df):
    def f(v):
        if pd.isna(v):return 'NA'
        return f'{v:.6g}' if isinstance(v,(float,np.floating)) else str(v)
    return '\n'.join(['| '+' | '.join(df.columns)+' |','| '+' | '.join(['---']*len(df.columns))+' |']+['| '+' | '.join(f(x) for x in row)+' |' for row in df.itertuples(index=False,name=None)])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path('results/reference_v13'))
    args=parser.parse_args();out=args.output.resolve();paper=out/'paper'
    for group in ('main','supplementary'):(paper/group).mkdir(parents=True,exist_ok=True)
    primary=pd.read_csv(out/'factorial_results.csv');accepted=primary[primary.primary_accepted==True]
    ref=json.loads((out/'cases/reference/summary.json').read_text());eps=ref['eps_BR'];delta=ref['delta']
    manifest={'main_tables':[],'main_figures':[],'supplementary_tables':[],'supplementary_figures':[]}
    def table(group,name,df,caption):
        df.to_csv(paper/group/(name+'.csv'),index=False)
        (paper/group/(name+'.md')).write_text(caption+'\n\n'+markdown(df)+'\n')
        manifest[group+'_tables'].append({'name':name,'caption':caption,'rows':len(df)})
    def fig(group,name,figure,caption):
        for ext in ('png','pdf'):figure.savefig(paper/group/(name+'.'+ext),dpi=300,bbox_inches='tight')
        # Render at 600 dpi from the figure; do not upscale the 300-dpi PNG.
        raster=io.BytesIO();figure.savefig(raster,format='png',dpi=600,bbox_inches='tight');raster.seek(0)
        with Image.open(raster) as image:image.convert('RGB').save(paper/group/(name+'.tif'),format='TIFF',compression='tiff_lzw',dpi=(600,600))
        plt.close(figure);manifest[group+'_figures'].append({'name':name,'caption':caption,'formats':['png','pdf','tif'],'png_dpi':300,'tiff_dpi':600,'tiff_colour_mode':'RGB','tiff_compression':'LZW'})
    plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False,'axes.titlesize':12,'axes.labelsize':12,'legend.fontsize':10,'savefig.facecolor':'white'})
    def stats(df):
        a=df[df.primary_accepted==True]
        return {'tested':len(df),'accepted':len(a),'mean_delta':a.delta_x_T.mean(),'median_delta':a.delta_x_T.median(),
                'min_delta':a.delta_x_T.min(),'max_delta':a.delta_x_T.max(),'TER':float((a.delta_x_T>delta).mean()),'n_exceeded':int((a.delta_x_T>delta).sum())}
    ps=stats(primary)
    rows=[('Tested configurations',len(primary)),('Grid and path accepted',len(accepted)),('Acceptance coverage (%)',100*len(accepted)/len(primary)),
          ('Mean terminal suppression',accepted.delta_x_T.mean()),('Median terminal suppression',accepted.delta_x_T.median()),
          ('Minimum terminal suppression',accepted.delta_x_T.min()),('Maximum terminal suppression',accepted.delta_x_T.max()),
          ('Above the terminal threshold',int((accepted.delta_x_T>delta).sum())),('Threshold exceedance (%)',100*(accepted.delta_x_T>delta).mean()),
          ('Sampled stage checks passed',int(primary.sampled_stage_verified.sum())),('Whole-policy initial gain at most 0.0001',int((primary.primary_accepted & primary.policy_initial_pass_1e4).sum()))]
    table('main','Table1_factorial_summary',pd.DataFrame(rows,columns=['Measure','Value']),f'Table 1. Factorial outcomes conditional on grid and path acceptance. Terminal suppression is a theoretical state difference. The threshold is {delta:g}; the whole-policy test uses a diagnostic state spacing of 0.025 and is a separate approximate check. No confidence interval or empirical success rate is implied.')
    comparisons=pd.read_csv(out/'cases/reference/comparisons.csv')
    table('main','Table2_reference_policy_comparisons',comparisons[['policy','x_T','delta_x_T_vs_no_defence','discounted_defender_utility','discounted_defence_cost']], 'Table 2. Reference-case policy comparisons. Each fixed defence is a commitment policy with an analytically re-optimised attacker. Mutual myopic actions resolve a one-period game. The dynamic response to sampled myopic defence uses a fine-grid approximation with interpolated actions. Lower terminal state alone does not rank the defender\'s total payoff.')
    oat=pd.read_csv(out/'sensitivity_results.csv');sensitivity=[]
    for key,levels in core.LEVELS.items():
        subset=oat[oat.case_id.str.startswith('oat_'+key+'_')];s=stats(subset)
        sensitivity.append({'parameter':key,'tested_levels':s['tested'],'accepted_levels':s['accepted'],'min_suppression':s['min_delta'],'max_suppression':s['max_delta'],'range':s['max_delta']-s['min_delta']})
    sensitivity=pd.DataFrame(sensitivity)
    table('main','Table3_sensitivity_ranges',sensitivity,'Table 3. One-at-a-time terminal-suppression ranges over the stated intervals. Each parameter retains its own scale; this is not a standardised or global importance ranking. Repeated reference tuples across dimensions are deliberate.')
    settings=json.loads((out/'cases/reference/parameters.json').read_text());settingrows=[]
    meaning={'x0':'Initial theoretical state','theta':'Fixed-pair susceptibility','kappa_A':'Attacker effort-cost coefficient','kappa_D':'Defender effort-cost coefficient','lam':'Defence-effectiveness coefficient','rho':'Weight on current response','gamma':'Discount factor','T':'Decision periods'}
    for key,label in meaning.items():settingrows.append({'group':'Model','setting':key,'reference':settings['params'][key],'meaning_or_levels':label+'; levels '+str(core.LEVELS[key])})
    for key in ('response_law','defender_loss'):settingrows.append({'group':'Model','setting':key,'reference':settings['params'][key],'meaning_or_levels':'Assumed functional form'})
    numerical_meanings={'dx':'Spacing of the primary state grid','seed_step':'Spacing for deterministic search starts only','eps_ne':'Continuous unilateral stage-regret tolerance','strict_tol':'Near-zero candidate tolerance','optimizer_tol':'Optimizer tolerance and regret-comparison slack','root_tol':'Best-response fixed-point root tolerance','root_maxfev':'Root evaluation budget','cluster_tol':'Distance for clustering discovered candidates','selection_tie_tol':'Tolerance for selection ties','global_audit_maxiter':'DE iteration budget when local search fails','global_audit_popsize':'DE population multiplier','global_audit_seed':'Reproducible primary DE seed','delta':'Strict terminal-suppression threshold','audit_subdivisions':'Diagnostic policy grid is dx divided by this value','offgrid_subdivisions':'Uniform state-probe grid is dx divided by this value','policy_mode':'Current-state strategy interface'}
    for key in ('dx','seed_step','eps_ne','strict_tol','optimizer_tol','root_tol','root_maxfev','cluster_tol','selection_tie_tol','global_audit_maxiter','global_audit_popsize','global_audit_seed','delta','audit_subdivisions','offgrid_subdivisions','policy_mode'):
        settingrows.append({'group':'Numerical','setting':key,'reference':str(settings['numerics'][key]),'meaning_or_levels':numerical_meanings[key]})
    table('supplementary','TableS1_model_and_numerics',pd.DataFrame(settingrows),'Supplementary Table S1. Assumed model parameters, sensitivity intervals, and primary numerical settings. No parameter is estimated from LLM observations. Full machine-readable settings, including the three deep-audit seeds and budgets, accompany every case.')
    conditional=[]
    for key in ('theta','lam','kappa_A','kappa_D'):
        for level in core.LEVELS[key]:
            subset=primary[primary[key]==level];s=stats(subset)
            conditional.append({'parameter':key,'level':level,'tested':s['tested'],'accepted':s['accepted'],'mean_suppression':s['mean_delta'],'threshold_exceedance':s['TER']})
    table('supplementary','TableS2_conditional_factorial',pd.DataFrame(conditional),'Supplementary Table S2. Conditional factorial summaries. Each row averages over the other three factorial dimensions. The accepted count is reported with the conditional mean so missing cases are visible. These rows are descriptive and do not isolate a causal architectural effect.')
    diagnostics=[]
    for phase in ('grid','initialization','policy_refinement'):
        frame=pd.read_csv(out/(phase+'_results.csv'))
        for r in frame.to_dict('records'):
            folder=out/'cases'/r['case_id'];pars=json.loads((folder/'parameters.json').read_text())
            diagnostics.append({'panel':phase,'case':r['case_id'],'setting':('dx='+str(r['dx']) if phase=='grid' else 'seed='+str(pars['numerics']['seed_step']) if phase=='initialization' else r['policy_definition']+'; audit dx='+str(r['policy_audit_dx'])),
                                'accepted':r['primary_accepted'],'sampled_stage_pass':r['sampled_stage_verified'],
                                'terminal_suppression':r.get('delta_x_T',np.nan),'grid_max_regret':r.get('grid_max_stage_regret',r.get('failure_best_regret',np.nan)),
                                'initial_policy_gain':r.get('policy_initial_max_gain',np.nan),'path_max_regret':r.get('path_max_stage_regret',np.nan)})
    tolerance=pd.read_csv(out/'tolerance_results.csv')
    for eps_,frame in tolerance.groupby('eps_BR'):
        st=stats(frame);diagnostics.append({'panel':'tolerance','case':f'{len(frame)} factorial cases','setting':'epsilon='+str(eps_),'accepted':st['accepted'],'sampled_stage_pass':'not run','terminal_suppression':st['mean_delta'],'grid_max_regret':np.nan,'initial_policy_gain':np.nan,'path_max_regret':np.nan,'tested':st['tested'],'TER':st['TER']})
    table('supplementary','TableS3_numerical_checks',pd.DataFrame(diagnostics),'Supplementary Table S3. State-grid, initialization, whole-policy diagnostic-resolution, and tolerance checks. Whole-policy resolution changes only the audit, not the stored primary continuation grid. Tolerance runs check every solver state and the realised path; broader state and whole-policy audits are not run for that auxiliary phase. Failed state-grid cases retain missing terminal outcomes.')
    robustness=[]
    for threshold in (.01,.025,.05):robustness.append({'panel':'threshold','setting':threshold,'tested':len(primary),'accepted':len(accepted),'mean_suppression':accepted.delta_x_T.mean(),'TER':float((accepted.delta_x_T>threshold).mean())})
    selection=pd.read_csv(out/'selection_results.csv');selection['primary_case']=selection.case_id.str.extract(r'selection_(factorial_\d+)_')
    good=selection.pivot(index='primary_case',columns='selection_rule',values='primary_accepted')
    common=good.index[good.fillna(False).all(axis=1)]
    for rule,frame in selection.groupby('selection_rule'):
        paired=frame[frame.primary_case.isin(common)];st=stats(frame)
        robustness.append({'panel':'selection','setting':rule,'tested':len(frame),'accepted':st['accepted'],'common_cohort':len(common),'mean_suppression':paired.delta_x_T.mean(),'TER':float((paired.delta_x_T>delta).mean())})
    specs=pd.read_csv(out/'specification_results.csv')
    for (law,loss),frame in specs.groupby(['response_law','defender_loss']):
        keys=['theta','lam','kappa_A','kappa_D'];matched=frame.merge(primary[keys+['primary_accepted','delta_x_T']],on=keys,suffixes=('_alt','_primary'))
        cohort=matched[(matched.primary_accepted_alt==True)&(matched.primary_accepted_primary==True)]
        st=stats(frame);robustness.append({'panel':'specification','setting':law+' / '+loss,'tested':len(frame),'accepted':st['accepted'],'common_cohort':len(cohort),'mean_suppression':cohort.delta_x_T_alt.mean(),'matched_primary_mean':cohort.delta_x_T_primary.mean(),'TER':float((cohort.delta_x_T_alt>delta).mean())})
    failed=primary[primary.primary_accepted==False]
    for r in failed.to_dict('records'):
        robustness.append({'panel':'failure','setting':r['case_id'],'theta':r['theta'],'lambda':r['lam'],'kappa_A':r['kappa_A'],'kappa_D':r['kappa_D'],'stage':r['failure_stage'],'state':r['failure_state'],'best_regret':r['failure_best_regret']})
    table('supplementary','TableS4_assumptions_and_failures',pd.DataFrame(robustness),'Supplementary Table S4. Threshold, candidate-selection, functional-form, and unresolved-case checks. Selection means use the common cohort accepted under all five rules with the same expanded search profile. Each alternative functional form is compared with the primary model on its own matched accepted cohort. This is a targeted 36-case check per alternative, not a repetition of the full 256-case design. The failure residual is the primary search result; seeded audit records remain in the raw archive.')
    tr=pd.read_csv(out/'cases/reference/trajectory.csv');nd=pd.read_csv(out/'cases/reference/comparison_paths.csv');nd=nd[nd.policy=='no_defence_dynamic_attacker']
    f,ax=plt.subplots(1,2,figsize=(9.2,3.8),layout='constrained')
    ax[0].plot(tr.t,tr.a,'o-',label='Attack effort',color='#b35c12');ax[0].plot(tr.t,tr.d,'s-',label='Defence effort',color='#2166ac')
    ax[0].set(xlabel='Decision period',ylabel='Effort',ylim=(0,1));ax[0].legend(loc='best');ax[0].text(.02,.97,'(a)',transform=ax[0].transAxes,va='top',fontweight='bold',fontsize=15)
    ts=np.arange(len(tr)+1)
    ax[1].plot(ts,np.r_[tr.x_t.iloc[0],tr.x_next], 'o-',label='Defended state',color='#2166ac',linewidth=2)
    ax[1].plot(ts,np.r_[nd.x_t.iloc[0],nd.x_next], 's--',label='No-defence state',color='#6b6b6b',linewidth=2)
    ax[1].set(xlabel='State time',ylabel='Theoretical transferability state',ylim=(0,.6));ax[1].legend(loc='lower left');ax[1].text(.02,.97,'(b)',transform=ax[1].transAxes,va='top',fontweight='bold',fontsize=15)
    for a in ax:a.grid(axis='y',alpha=.2)
    fig('main','Figure1_reference_dynamics',f,'Figure 1. Reference dynamics. (a) Resolved attack and defence effort in each decision period. (b) Persistent state under the defended strategy and the no-defence benchmark, whose attacker re-optimises dynamically. State paths include the shared initial state. Both panel letters and both state lines are shown. The plotted paths do not establish a continuous-state equilibrium.')
    mat=accepted.groupby(['theta','lam']).delta_x_T.mean().unstack().reindex(index=core.LEVELS['theta'],columns=core.LEVELS['lam'])
    counts=accepted.groupby(['theta','lam']).size().unstack().reindex_like(mat)
    f,ax=plt.subplots(figsize=(6.8,4.4),layout='constrained');im=ax.imshow(mat.to_numpy(),origin='lower',cmap='Blues',vmin=0)
    ax.set_xticks(range(4),[str(x) for x in mat.columns]);ax.set_yticks(range(4),[str(x) for x in mat.index]);ax.set(xlabel=r'Defence effectiveness $\lambda$',ylabel=r'Pair susceptibility $\theta_{sj}$')
    for i in range(4):
        for j in range(4):
            ax.text(j,i,f'{mat.iloc[i,j]:.4f}\n{int(counts.iloc[i,j])}/16',ha='center',va='center',fontsize=11,color='white' if mat.iloc[i,j]>mat.max().max()*.65 else 'black')
    f.colorbar(im,ax=ax,label='Mean terminal suppression')
    fig('main','Figure2_susceptibility_effectiveness',f,'Figure 2. Mean terminal suppression by susceptibility and defence effectiveness, conditional on grid and path acceptance. Each cell shows its mean and accepted count out of 16. The two cost dimensions are averaged within the cell. Counts replace a separate coverage heatmap.')
    f,axes=plt.subplots(4,2,figsize=(8.4,10),layout='constrained');ylim=max(float(sensitivity.max_suppression.max()),delta)*1.10
    figure3_panels=[]
    for i,(ax,(key,levels)) in enumerate(zip(axes.ravel(),core.LEVELS.items())):
        frame=oat[oat.case_id.str.startswith('oat_'+key+'_')].sort_values(key);valid=frame[frame.primary_accepted==True]
        # NaN values leave gaps; an unresolved level is never a zero suppression.
        ys=np.where(frame.primary_accepted,frame.delta_x_T,np.nan)
        ax.plot(frame[key],ys,'o-',color='#2166ac',linewidth=1.8)
        bad=frame[frame.primary_accepted==False]
        if len(bad):ax.text(.97,.92,'Unresolved: '+', '.join(f'{v:g}' for v in bad[key]),transform=ax.transAxes,ha='right',va='top',color='#b2182b',fontsize=10,bbox={'facecolor':'white','edgecolor':'none','alpha':.9})
        ax.axhline(delta,color='#777777',linestyle=':',linewidth=1)
        ax.set(xlabel=core.MATH_LABELS[key],ylabel='Terminal suppression',ylim=(0,ylim));ax.grid(axis='y',alpha=.2)
        ax.set_xticks(levels,[f'{value:g}' for value in levels])
        margin=.05*(max(levels)-min(levels));ax.set_xlim(min(levels)-margin,max(levels)+margin)
        ax.text(.02,.96,'('+chr(97+i)+')',transform=ax.transAxes,va='top',fontweight='bold',fontsize=13)
        # These records come from the actual Matplotlib lines and axes being saved.
        line=ax.lines[0];figure3_panels.append({'panel':chr(97+i),'parameter':key,'xlabel':ax.get_xlabel(),'x':line.get_xdata().tolist(),'y':line.get_ydata().tolist(),'xticks':ax.get_xticks().tolist(),'ylim':list(ax.get_ylim()),'unresolved_levels':bad[key].tolist(),'threshold':float(ax.lines[1].get_ydata()[0])})
    (paper/'main/Figure3_plot_records.json').write_text(json.dumps(safe(figure3_panels),indent=2,allow_nan=False)+'\n')
    fig('main','Figure3_one_at_a_time',f,'Figure 3. One-at-a-time terminal suppression around the reference case. Panels (a)–(h) vary initial state, susceptibility, attacker cost, defender cost, defence effectiveness, current-response weight, discount factor, and horizon, respectively. All panels use one vertical scale and ticks at the tested levels. The dotted line is the descriptive threshold. The susceptibility level 0.8 is unresolved: it is named in panel (b) and has no plotted outcome. Lines guide the eye across accepted tested levels. The small initial-state range is reported in Table 3; its apparent flatness at this common scale does not imply exact independence.')
    interp=out/'cases/policy_audit_interpolated_2/stage_audit.csv';audit0=pd.read_csv(out/'cases/reference/stage_audit.csv');audit1=pd.read_csv(interp)
    f,ax=plt.subplots(1,2,figsize=(9.2,3.9),layout='constrained')
    for frame,name,color in [(audit0,'State-by-state resolving','#2166ac'),(audit1,'Action interpolation','#b35c12')]:
        values=frame[frame.domain=='uniform_probe'].groupby('t').max_regret.max();ax[0].plot(values.index,values,'o-',label=name,color=color)
    ax[0].axhline(eps,color='#777777',linestyle=':',label='Stage tolerance');ax[0].set(xlabel='Decision period',ylabel='Maximum sampled stage regret');ax[0].legend(fontsize=10)
    audits=pd.read_csv(out/'policy_refinement_results.csv')
    for mode,color in [('resolved','#2166ac'),('interpolated','#b35c12')]:
        a=audits[audits.policy_definition==mode].sort_values('policy_audit_dx',ascending=False);ax[1].plot(range(len(a)),a.policy_initial_max_gain,'o-',label=mode,color=color)
    ax[1].set_xticks(range(3),['0.0500','0.0250','0.0125']);ax[1].axhline(1e-4,color='#777777',linestyle=':');ax[1].set(xlabel='Whole-policy diagnostic spacing',ylabel='Initial remaining-policy deviation gain');ax[1].legend(fontsize=10)
    for i,a in enumerate(ax):a.text(.02,1.02,'('+chr(97+i)+')',transform=a.transAxes,va='bottom',fontweight='bold',fontsize=14);a.grid(axis='y',alpha=.2)
    fig('supplementary','FigureS1_verification_domains',f,'Supplementary Figure S1. Reference verification domains. (a) Maximum local stage regret over the solver grid and midpoint probes for the resolved primary strategy and the interpolated-action sensitivity strategy. (b) Initial whole-policy deviation gains at three diagnostic spacings with the primary continuation grid fixed at 0.05. The dotted gain line marks 0.0001. These approximate whole-policy checks are not a proof about unsampled states or a convergence study of the primary solver.')
    metrics={'factorial':ps,'reference':ref,'oat':sensitivity.to_dict('records'),'verification_counts':{'grid':int(primary.grid_accepted.sum()),'path':int(primary.path_stage_verified.sum()),'sampled':int(primary.sampled_stage_verified.sum()),'whole_policy_initial':int((primary.primary_accepted & primary.policy_initial_pass_1e4).sum())},'selection_eligible':int(selection.primary_case.nunique()),'selection_common':len(common),'failed_cases':failed.to_dict('records'),'planned_case_count':sum(1 for _ in (out/'cases').glob('*/COMPLETE.json'))}
    (out/'paper_metrics.json').write_text(json.dumps(safe(metrics),indent=2,allow_nan=False)+'\n')
    (paper/'OUTPUT_INDEX.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (paper/'CAPTIONS.md').write_text('\n\n'.join(item['caption'] for group in manifest.values() for item in group)+'\n')
    (paper/'REMOVED_FROM_PAPER.md').write_text('The suppression histogram, separate coverage heatmap, cost heatmap, full-candidate scatter plots, repeated tolerance figures, duplicate baseline figures, and per-case diagnostic plots are not separate paper items. Their values remain in the raw case files and phase CSVs. The paper set has 3 main figures, 3 main tables, 1 supplementary figure and 4 supplementary tables.\n')
    print('Exported 3 main figures, 3 main tables, 1 supplementary figure and 4 supplementary tables.')

if __name__=='__main__':main()
