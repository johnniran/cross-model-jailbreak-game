"""Independent numerical and analytical checks; run with unittest."""
import unittest
from dataclasses import replace
from unittest.mock import patch
import numpy as np
from llm_jailbreak_game import core


class NumericalChecks(unittest.TestCase):
    def test_no_defence_formula_across_clipped_and_interior_cases(self):
        for theta,rho,ka,T in [(.6,.5,.5,10),(.8,.25,1.5,7),(.8,.75,.25,5),(0.,.5,.5,3)]:
            p=replace(core.BASELINE,theta=theta,rho=rho,kappa_A=ka,T=T)
            n=replace(core.NUM,dx=.1)
            actual=core.solve_no_defense(p,n);expected=core.analytic_fixed_defence(p,n)
            np.testing.assert_allclose(actual['policy_A'],expected['policy_A'],atol=1e-11,rtol=0)
            np.testing.assert_allclose(core.trajectory(p,actual).x_next,core.trajectory(p,expected).x_next,atol=1e-11,rtol=0)

    def test_reference_no_defence_terminal_value(self):
        path=core.trajectory(core.BASELINE,core.analytic_fixed_defence(core.BASELINE,core.NUM))
        self.assertAlmostEqual(path.x_next.iloc[-1],.46265234375,places=12)

    def test_global_best_responses_against_independent_dense_actions(self):
        # Oscillating continuation values test kinks and nonconcave pieces.
        rng=np.random.default_rng(20261004);grid=core.unit_grid(.1);actions=np.linspace(0.,1.,20001)
        for law in ['rational','exponential']:
            for loss in ['quadratic','linear']:
                p=replace(core.BASELINE,response_law=law,defender_loss=loss)
                for _ in range(4):
                    x,a,d=rng.uniform(0.,1.,3);va=rng.normal(0.,.3,len(grid));vd=rng.normal(0.,.3,len(grid))
                    aa,qa=core.continuous_best_response_attacker(x,d,va,grid,p)
                    dd,qd=core.continuous_best_response_defender(x,a,vd,grid,p)
                    ya=core.F(x,actions,d,p);yd=core.F(x,a,actions,p)
                    dense_a=core.U_A(x,actions,d,p)+p.gamma*np.interp(ya,grid,va)
                    dense_d=core.U_D(x,a,actions,p)+p.gamma*np.interp(yd,grid,vd)
                    self.assertGreaterEqual(qa+1e-10,float(dense_a.max()))
                    self.assertGreaterEqual(qd+1e-10,float(dense_d.max()))
                    self.assertAlmostEqual(core._Q_A_scalar(aa,x,d,va,grid,p),qa,places=10)
                    self.assertAlmostEqual(core._Q_D_scalar(dd,x,a,vd,grid,p),qd,places=10)

    def test_final_stage_attacker_exact_formula(self):
        grid=core.unit_grid(.05);zero=np.zeros(len(grid));p=core.BASELINE
        for x in [0.,.3,1.]:
            for d in [0.,.27,1.]:
                a,_=core.continuous_best_response_attacker(x,d,zero,grid,p)
                self.assertAlmostEqual(a,min(1.,p.rho*p.theta/(p.kappa_A*(1+p.lam*d))),places=12)

    def test_trajectory_uses_declared_policy_without_resolving(self):
        p=replace(core.BASELINE,x0=.3,T=2)
        solution={'x_grid':np.array([0.,1.]),'policy_A':np.array([[0.,1.],[.2,.8]]),'policy_D':np.array([[1.,0.],[.1,.5]])}
        with patch.object(core,'solve_stage_game',side_effect=AssertionError('No off-grid re-solve allowed')):
            tr=core.trajectory(p,solution)
        self.assertAlmostEqual(tr.a.iloc[0],.3)
        self.assertAlmostEqual(tr.d.iloc[0],.7)
        for row in tr.itertuples():self.assertAlmostEqual(row.x_next,float(core.F(row.x_t,row.a,row.d,p)))

    def test_cumulative_costs_and_utilities_are_consistent(self):
        p=core.BASELINE;tr=core.trajectory(p,core.analytic_fixed_defence(p,core.NUM,.5))
        m=core.cumulative_outcomes(tr)
        self.assertAlmostEqual(m['discounted_attacker_utility'],m['discounted_state_sum']-m['discounted_attack_cost'])
        self.assertAlmostEqual(m['discounted_defender_utility'],-m['discounted_defender_state_loss']-m['discounted_defence_cost'])

    def test_zero_susceptibility_has_zero_effort(self):
        p=replace(core.BASELINE,theta=0.,T=3);n=replace(core.NUM,dx=.2)
        result=core.run_configuration(p,n,keep_objects=True,comparisons=False)
        self.assertTrue(result['summary']['grid_accepted'])
        self.assertTrue(result['summary']['sampled_stage_verified'])
        self.assertTrue(result['summary']['path_stage_verified'])
        np.testing.assert_allclose(result['solution']['policy_A'],0.,atol=1e-8)
        np.testing.assert_allclose(result['solution']['policy_D'],0.,atol=1e-8)
        self.assertLessEqual(result['summary']['policy_all_states_max_gain'],1e-10)

    def test_full_policy_audit_detects_deliberately_bad_policy(self):
        p=replace(core.BASELINE,theta=.8,T=3);n=replace(core.NUM,dx=.2)
        g=core.unit_grid(n.dx)
        bad={'success':True,'x_grid':g,'policy_A':np.zeros((p.T,len(g))),'policy_D':np.ones((p.T,len(g)))}
        audit=core.compute_policy_exploitability(p,n,bad)
        self.assertGreater(audit['summary']['policy_initial_gain_A'],.01)
        self.assertGreater(audit['summary']['policy_initial_gain_D'],.01)
        self.assertEqual(len(audit['points']),p.T*len(core.unit_grid(n.dx/n.audit_subdivisions)))

    def test_memoryless_policy_reduces_to_stage_game(self):
        n=replace(core.NUM,dx=.2)
        short=core.solve_mpne(replace(core.BASELINE,rho=1.,T=1,gamma=.8),n)
        long=core.solve_mpne(replace(core.BASELINE,rho=1.,T=3,gamma=1.),n)
        self.assertTrue(short['success']);self.assertTrue(long['success'])
        np.testing.assert_allclose(long['policy_A'],np.repeat(short['policy_A'],3,axis=0),atol=1e-6,rtol=0)
        np.testing.assert_allclose(long['policy_D'],np.repeat(short['policy_D'],3,axis=0),atol=1e-6,rtol=0)

    def test_invalid_parameters_raise_without_python_assertions(self):
        for p in [replace(core.BASELINE,theta=np.nan),replace(core.BASELINE,T=2.5),replace(core.BASELINE,T=True),replace(core.BASELINE,kappa_A=0.)]:
            with self.assertRaises(ValueError):core.validate_params(p)
        for n in [replace(core.NUM,dx=.3),replace(core.NUM,eps_ne=np.nan),replace(core.NUM,audit_subdivisions=0)]:
            with self.assertRaises(ValueError):core.validate_numerics(n)



class DeclaredStrategyChecks(unittest.TestCase):
    def test_resolved_offgrid_strategy_is_cached_and_grid_actions_remain_authoritative(self):
        p=replace(core.BASELINE,T=1);n=replace(core.NUM,dx=.5)
        s=core.solve_mpne(p,n)
        exact_grid=core.policy_actions(s,0,.5)
        self.assertEqual(exact_grid,(float(s['policy_A'][0,1]),float(s['policy_D'][0,1])))
        pair=core.policy_actions(s,0,.37)
        regret=core.continuous_pair_regret(.37,*pair,s['V_A'][1],s['V_D'][1],s['x_grid'],p)
        self.assertLessEqual(regret['max_regret'],n.eps_ne+n.optimizer_tol)
        with patch.object(core,'solve_stage_game',side_effect=AssertionError('Cached strategy must not change')):
            self.assertEqual(pair,core.policy_actions(s,0,.37))

    def test_failed_offgrid_search_is_explicitly_recorded(self):
        p=replace(core.BASELINE,T=1);n=replace(core.NUM,dx=.5)
        s=core.solve_mpne(p,n)
        failed={'success':False,'diagnostic':{'a':.1,'d':.2,'max_regret':.3,'method':'test'}}
        with patch.object(core,'solve_stage_game',return_value=failed):
            self.assertEqual(core.policy_actions(s,0,.37),(.1,.2))
        self.assertEqual(s['offgrid_search_failures'][(0,.37)]['max_regret'],.3)

    def test_invalid_policy_modes_search_budgets_and_seeds(self):
        for n in [replace(core.NUM,policy_mode='other'),replace(core.NUM,root_maxfev=80.5),replace(core.NUM,global_audit_seed=-1),replace(core.NUM,deep_audit_popsize=True)]:
            with self.assertRaises(ValueError):core.validate_numerics(n)

class CheckpointChecks(unittest.TestCase):
    def test_resume_rejects_changed_file_and_changed_settings(self):
        import tempfile,sys,json
        from pathlib import Path
        scripts=Path(__file__).resolve().parents[1]/'scripts'
        sys.path.insert(0,str(scripts))
        from run_analysis import execute_case,checkpoint_valid
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp);p=replace(core.BASELINE,T=1);n=replace(core.NUM,dx=.5)
            first=execute_case('test_checkpoint',p,n,out)
            folder=out/'cases/test_checkpoint';signature=json.loads((folder/'parameters.json').read_text())
            self.assertTrue(checkpoint_valid(folder,signature))
            file=folder/'trajectory.csv';file.write_text(file.read_text()+'\ncorruption\n')
            self.assertFalse(checkpoint_valid(folder,signature))
            second=execute_case('test_checkpoint',p,n,out,resume=True)
            self.assertAlmostEqual(first['x_T_star'],second['x_T_star'])
            self.assertTrue(checkpoint_valid(folder,signature))
            other=dict(signature);other['numerics']=dict(signature['numerics'],dx=.25)
            self.assertFalse(checkpoint_valid(folder,other))

    def test_resolved_search_honours_disabled_global_search(self):
        p=replace(core.BASELINE,T=1);n=replace(core.NUM,dx=.5)
        s=core.solve_mpne(p,n,allow_global_audit=False)
        with patch.object(core,'solve_stage_game',return_value={'success':True,'a':.1,'d':.2}) as called:
            core.policy_actions(s,0,.37)
        self.assertIs(called.call_args.kwargs['allow_global_audit'],False)

    def test_repeated_myopic_policy_has_valid_stage_audits(self):
        p=replace(core.BASELINE,T=3);n=replace(core.NUM,dx=.5)
        s=core.myopic_policy(p,n);path=core.trajectory(p,s)
        audit=core.audit_stage_policy(p,n,s,path)
        self.assertTrue(audit.pass_stage_tolerance.all())

if __name__=='__main__':unittest.main()
