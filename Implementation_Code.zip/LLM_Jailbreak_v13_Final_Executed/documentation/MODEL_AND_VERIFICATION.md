# Model and verification definitions

## Scope

Each scenario is an independent scalar game for one theoretical ordered pair.
Susceptibility is assumed, not a measured transfer matrix or architecture-only
effect. One period is aggregate resource allocation, not one conversation
turn. The persistent state is a theoretical vulnerability index, not an ASR.

## Equations and boundary checks

For the primary rational response:

```text
tau = theta*a/(1+lambda*d)
F = (1-rho)*x + rho*tau
U_A = F - kappa_A*a^2/2
U_D = -F^2 - kappa_D*d^2/2
Q_i,t = U_i + gamma*interpolate(V_i,t+1,F)
V_i,T = 0
```

The convex update preserves [0,1]. State expansion gives
`x_t=(1-rho)^t*x0+rho*sum_k (1-rho)^(t-1-k)*tau_k`.
The defender stage cross-partial is
`2*(1-rho)*rho*theta*lambda*a/(1+lambda*d)^2`. It is nonnegative,
zero at rho=1, and is not a theorem about the full equilibrium policy.

For fixed defensive commitment d, the attacker action is
`min(1,rho*theta/(kappa_A*(1+lambda*d))*sum_k[gamma*(1-rho)]^k)`
with k from zero to T-t-1. The exponential variant replaces the rational
susceptibility factor with `theta*exp(-lambda*d)`. This benchmark is checked
against a separate numerical attacker recursion.

At the final stage, attacker best response clips
`rho*theta/(kappa_A*(1+lambda*d))` to [0,1]. For an interior defence optimum,
`kappa_D*d=2*rho*theta*lambda*a*F/(1+lambda*d)^2`. Boundary derivative signs
apply at zero and one. Small-regret actions need not equal exact stationary
points. At rho=1, the tested dynamic policies reduce to the repeated static
game under the adopted selection convention.

## Best responses and search

Continuation values are piecewise linear. For fixed defence, the attacker
objective is quadratic within each interpolation segment: enumerate all
boundaries and interior stationary points. For fixed attack under rational
attenuation, the defender first-order equation is quartic after a denominator
transformation. Every real in-segment root and boundary is evaluated. The
exponential variant uses the corresponding derivative-root partition. These
are global one-dimensional best responses to the adopted interpolated value
functions. They do not solve the full two-player stage game globally.

The two-player stage search uses deterministic multistart roots, bounded
least-squares refinement, Powell regret minimization, and a seeded
DE audit when no pair passes. Failure means this configured search found no
accepted pair. It does not prove equilibrium non-existence.

The primary selection chooses the near-zero pool first if found, then the
small-regret pool, with regret minimization and deterministic action ties.
Alternative rules select over discovered accepted epsilon candidates. They
share the expanded search profile in the matched comparison. Discovered
candidate counts do not establish exact-equilibrium multiplicity.

## Declared strategies

`resolved` is the primary strategy: stored grid actions are authoritative,
while off-grid current-state actions are re-solved against the stored
continuation values. The interpolated grid actions supply one warm start.
The search profile, rule and global-search option are propagated. Results
are cached by stage and exact query state. Values within 1e-12 of a solver
state use the stored grid action. Failed off-grid candidates are retained
only to define the diagnostic strategy; their regret flags remain false.

`interpolated` is a separate sensitivity strategy. It linearly interpolates
stored actions, without a new stage solve. It must not be substituted for the
primary manuscript method or treated as an equivalent policy.

## Acceptance and diagnostics

Primary acceptance requires grid and realised-path continuous unilateral
stage regrets at most `eps_ne+optimizer_tol`. The maximum is taken across
both players. Midpoint probes are separate sampled tests. Neither finite
domain supplies a continuous-state equilibrium proof.

Remaining-policy deviation estimates use the same declared opponent policy
in the policy evaluation and dynamic best-response recursions, with a common
diagnostic state grid. Values at next states are interpolated. Signed gains
are retained, so clipping cannot conceal evaluation errors. A discounted sum
of stage tolerances is only a comparison scale. The whole-policy estimate is
not the same quantity as local regret against primary continuation values.
Resolution dependence is reported, not described as convergence.

The full sampled audit is run for the seven declared main/diagnostic phases.
Tolerance, selection and memoryless phases use grid-and-path scope. Unrun
broader checks are null for successful cases. All domains are labelled in
parameters.json, summary.json and the phase CSVs.

## Policy outcomes and interpretation

Terminal suppression subtracts the defended terminal state from the
analytical no-defence terminal state. TER counts strict exceedance of delta
among primary accepted cases. A theoretical threshold proportion is not an
empirical success probability. Defender utility is the negative discounted
state loss plus negative discounted effort cost, so terminal suppression
alone does not rank defensive policies.

Fixed defence is a commitment comparison with an analytical attacker
response. Repeated mutual-myopic policy resolves the one-stage game. The
myopic-defender/dynamic-attacker comparison samples that defence on a finer
grid, solves the attacker's DP, then interpolates those sampled actions; it
is explicitly approximate. It is not an extra MPNE solution or a deployment
experiment. Structural variants are compared on matched accepted cohorts.
