# Version 13 revision record

The primary rational model and utility equations are retained. Version 12's
change from current-state solving to action interpolation is reversed in the
primary analysis; interpolation remains an explicitly named sensitivity
strategy. This correction is distinct from strengthening verification.

Added or corrected:

1. One strategy interface shared by paths, state probes and whole-policy audits.
2. Authoritative grid actions, cached off-grid actions and explicit failed candidates.
3. Global-search settings propagated to off-grid solving; repeated static-policy audits use the static continuation index.
4. Sorted and deduplicated best-response candidates for deterministic ties.
5. Correct primary-only near-zero-pool selection flag.
6. Validation of integer search budgets, seeds, policy modes and fixed-defence inputs.
7. Locked per-case writes, completion written last and file hashes checked on resume.
8. Independent transition, payoff, recursion, flag, phase and design verification with zero relative tolerance.
9. Separate primary, midpoint and whole-policy coverage; no continuous-state or convergence certificate.
10. Three main figures and tables, one supplementary figure and four supplementary tables.
11. Figure 1 labels (a) and (b), a defence-effort curve in (a), and both defended and no-defence state curves in (b).
12. Matched policy/selection/function-form comparisons and retention of every unresolved case.

The original manuscript already rejected an exact-equilibrium and numerical
convergence claim. That qualification should be retained. Necessary changes
include its universal whole-policy bound, all-level OAT acceptance statement,
and use of verified approximate-equilibrium coverage for a finite test domain.

Only published peer-reviewed papers are recommended in the Word revision
guide. Han and Zhu's preprint entry is removed. AGD is cited as an ACL 2025
long paper; PAIR as a SaTML 2025 paper, with the correct interpretation of each.

## Final TIFF and presentation audit

The solver source and recorded experiments are unchanged. All 16 tests and the
1674-case output verifier were rerun after installing the delivered package.
A separate paper-output verifier checks the actual exported Figure 3 line
records against raw paths, the 33-case one-at-a-time design, all seven tables,
and the four TIFF files. All other parameters are held at the reference in
each one-at-a-time case.

Figure 3 now ticks the tested levels, states that susceptibility 0.8 is
unresolved, and gives that case no outcome marker. The small nonzero
initial-state range is retained in Table 3. Every figure is independently
rendered at 600 dpi as an RGB TIFF with lossless LZW compression, alongside
300-dpi PNG previews and vector PDFs. The exporter reproduces all formats.

The proposed title now includes large language models. A stale correction-guide
reference to cost means in Table S2 is corrected: reference policy costs are
in Table 2 and full factorial cost records remain in the raw CSVs. The paper
set remains three main figures and tables, one supplementary figure and four
supplementary tables. No continuous-state equilibrium or convergence claim is
added.
