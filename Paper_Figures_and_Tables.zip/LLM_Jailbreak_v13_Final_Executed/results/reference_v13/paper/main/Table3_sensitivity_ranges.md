Table 3. One-at-a-time terminal-suppression ranges over the stated intervals. Each parameter retains its own scale; this is not a standardised or global importance ranking. Repeated reference tuples across dimensions are deliberate.

| parameter | tested_levels | accepted_levels | min_suppression | max_suppression | range |
| --- | --- | --- | --- | --- | --- |
| x0 | 5 | 5 | 0.154326 | 0.154555 | 0.000228423 |
| theta | 4 | 3 | 0.0011079 | 0.154326 | 0.153218 |
| kappa_A | 4 | 4 | 0.0185327 | 0.170244 | 0.151711 |
| kappa_D | 4 | 4 | 0.0939348 | 0.193972 | 0.100037 |
| lam | 4 | 4 | 0.08002 | 0.232344 | 0.152324 |
| rho | 4 | 4 | 0.104839 | 0.229467 | 0.124628 |
| gamma | 4 | 4 | 0.145589 | 0.15514 | 0.00955181 |
| T | 4 | 4 | 0.14845 | 0.154723 | 0.00627292 |
