Table 1. Factorial outcomes conditional on grid and path acceptance. Terminal suppression is a theoretical state difference. The threshold is 0.025; the whole-policy test uses a diagnostic state spacing of 0.025 and is a separate approximate check. No confidence interval or empirical success rate is implied.

| Measure | Value |
| --- | --- |
| Tested configurations | 256 |
| Grid and path accepted | 251 |
| Acceptance coverage (%) | 98.0469 |
| Mean terminal suppression | 0.0762285 |
| Median terminal suppression | 0.0299296 |
| Minimum terminal suppression | 4.1052e-06 |
| Maximum terminal suppression | 0.463419 |
| Above the terminal threshold | 131 |
| Threshold exceedance (%) | 52.1912 |
| Sampled stage checks passed | 249 |
| Whole-policy initial gain at most 0.0001 | 241 |
