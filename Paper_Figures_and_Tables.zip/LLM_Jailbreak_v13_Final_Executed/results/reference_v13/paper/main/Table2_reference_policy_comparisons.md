Table 2. Reference-case policy comparisons. Each fixed defence is a commitment policy with an analytically re-optimised attacker. Mutual myopic actions resolve a one-period game. The dynamic response to sampled myopic defence uses a fine-grid approximation with interpolated actions. Lower terminal state alone does not rank the defender's total payoff.

| policy | x_T | delta_x_T_vs_no_defence | discounted_defender_utility | discounted_defence_cost |
| --- | --- | --- | --- | --- |
| no_defence_dynamic_attacker | 0.462652 | 0 | -2.65957 | 0 |
| dynamic_nash_resolved | 0.308326 | 0.154326 | -1.3562 | 0.237215 |
| myopic_mutual | 0.278748 | 0.183904 | -0.780147 | 0.0420928 |
| myopic_defender_dynamic_attacker | 0.344073 | 0.118579 | -1.76821 | 0.0560582 |
| fixed_defence_0.25_dynamic_attacker | 0.302224 | 0.160429 | -1.58766 | 0.125395 |
| fixed_defence_0.50_dynamic_attacker | 0.210027 | 0.252626 | -1.30713 | 0.501579 |
| fixed_defence_0.75_dynamic_attacker | 0.154435 | 0.308217 | -1.63805 | 1.12855 |
| fixed_defence_1.00_dynamic_attacker | 0.118354 | 0.344299 | -2.36389 | 2.00632 |
