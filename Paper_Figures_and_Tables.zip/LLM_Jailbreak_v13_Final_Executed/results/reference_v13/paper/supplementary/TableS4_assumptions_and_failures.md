Supplementary Table S4. Threshold, candidate-selection, functional-form, and unresolved-case checks. Selection means use the common cohort accepted under all five rules with the same expanded search profile. Each alternative functional form is compared with the primary model on its own matched accepted cohort. This is a targeted 36-case check per alternative, not a repetition of the full 256-case design. The failure residual is the primary search result; seeded audit records remain in the raw archive.

| panel | setting | tested | accepted | mean_suppression | TER | common_cohort | matched_primary_mean | theta | lambda | kappa_A | kappa_D | stage | state | best_regret |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| threshold | 0.01 | 256 | 251 | 0.0762285 | 0.641434 | NA | NA | NA | NA | NA | NA | NA | NA | NA |
| threshold | 0.025 | 256 | 251 | 0.0762285 | 0.521912 | NA | NA | NA | NA | NA | NA | NA | NA | NA |
| threshold | 0.05 | 256 | 251 | 0.0762285 | 0.414343 | NA | NA | NA | NA | NA | NA | NA | NA | NA |
| selection | high_a | 101 | 98 | 0.101498 | 0.783505 | 97 | NA | NA | NA | NA | NA | NA | NA | NA |
| selection | high_d | 101 | 100 | 0.1015 | 0.783505 | 97 | NA | NA | NA | NA | NA | NA | NA | NA |
| selection | low_a | 101 | 101 | 0.101502 | 0.783505 | 97 | NA | NA | NA | NA | NA | NA | NA | NA |
| selection | low_d | 101 | 100 | 0.1015 | 0.783505 | 97 | NA | NA | NA | NA | NA | NA | NA | NA |
| selection | min_regret | 101 | 101 | 0.1015 | 0.783505 | 97 | NA | NA | NA | NA | NA | NA | NA | NA |
| specification | exponential / quadratic | 36 | 33 | 0.18799 | 0.666667 | 33 | 0.155463 | NA | NA | NA | NA | NA | NA | NA |
| specification | rational / linear | 36 | 36 | 0.179847 | 0.735294 | 34 | 0.161253 | NA | NA | NA | NA | NA | NA | NA |
| failure | factorial_196 | NA | NA | NA | NA | NA | NA | 0.8 | 0.5 | 0.5 | 0.25 | 2 | 0.35 | 0.000443708 |
| failure | factorial_213 | NA | NA | NA | NA | NA | NA | 0.8 | 1 | 0.5 | 0.5 | 4 | 0.2 | 0.00010085 |
| failure | factorial_214 | NA | NA | NA | NA | NA | NA | 0.8 | 1 | 0.5 | 1 | 2 | 0.35 | 0.00042795 |
| failure | factorial_230 | NA | NA | NA | NA | NA | NA | 0.8 | 1.5 | 0.5 | 1 | 2 | 0.35 | 0.000757003 |
| failure | factorial_231 | NA | NA | NA | NA | NA | NA | 0.8 | 1.5 | 0.5 | 1.5 | 2 | 0.05 | 0.000126022 |
