Supplementary Table S2. Conditional factorial summaries. Each row averages over the other three factorial dimensions. The accepted count is reported with the conditional mean so missing cases are visible. These rows are descriptive and do not isolate a causal architectural effect.

| parameter | level | tested | accepted | mean_suppression | threshold_exceedance |
| --- | --- | --- | --- | --- | --- |
| theta | 0.2 | 64 | 64 | 0.00269876 | 0 |
| theta | 0.4 | 64 | 64 | 0.0331363 | 0.375 |
| theta | 0.6 | 64 | 64 | 0.0984305 | 0.78125 |
| theta | 0.8 | 64 | 59 | 0.17865 | 0.966102 |
| lam | 0.5 | 64 | 63 | 0.0322764 | 0.380952 |
| lam | 1 | 64 | 62 | 0.0652412 | 0.516129 |
| lam | 1.5 | 64 | 62 | 0.0909992 | 0.580645 |
| lam | 2 | 64 | 64 | 0.115829 | 0.609375 |
| kappa_A | 0.25 | 64 | 64 | 0.131098 | 0.71875 |
| kappa_A | 0.5 | 64 | 59 | 0.106191 | 0.627119 |
| kappa_A | 1 | 64 | 64 | 0.0474582 | 0.4375 |
| kappa_A | 1.5 | 64 | 64 | 0.0225078 | 0.3125 |
| kappa_D | 0.25 | 64 | 63 | 0.107357 | 0.587302 |
| kappa_D | 0.5 | 64 | 63 | 0.0841815 | 0.555556 |
| kappa_D | 1 | 64 | 62 | 0.0605294 | 0.483871 |
| kappa_D | 1.5 | 64 | 63 | 0.0525973 | 0.460317 |
