Supplementary Table S1. Assumed model parameters, sensitivity intervals, and primary numerical settings. No parameter is estimated from LLM observations. Full machine-readable settings, including the three deep-audit seeds and budgets, accompany every case.

| group | setting | reference | meaning_or_levels |
| --- | --- | --- | --- |
| Model | x0 | 0.5 | Initial theoretical state; levels [0.1, 0.3, 0.5, 0.7, 0.9] |
| Model | theta | 0.6 | Fixed-pair susceptibility; levels [0.2, 0.4, 0.6, 0.8] |
| Model | kappa_A | 0.5 | Attacker effort-cost coefficient; levels [0.25, 0.5, 1.0, 1.5] |
| Model | kappa_D | 0.5 | Defender effort-cost coefficient; levels [0.25, 0.5, 1.0, 1.5] |
| Model | lam | 1 | Defence-effectiveness coefficient; levels [0.5, 1.0, 1.5, 2.0] |
| Model | rho | 0.5 | Weight on current response; levels [0.25, 0.5, 0.75, 1.0] |
| Model | gamma | 0.95 | Discount factor; levels [0.8, 0.9, 0.95, 1.0] |
| Model | T | 10 | Decision periods; levels [5, 10, 15, 20] |
| Model | response_law | rational | Assumed functional form |
| Model | defender_loss | quadratic | Assumed functional form |
| Numerical | dx | 0.05 | Spacing of the primary state grid |
| Numerical | seed_step | 0.05 | Spacing for deterministic search starts only |
| Numerical | eps_ne | 0.0001 | Continuous unilateral stage-regret tolerance |
| Numerical | strict_tol | 1e-09 | Near-zero candidate tolerance |
| Numerical | optimizer_tol | 1e-10 | Optimizer tolerance and regret-comparison slack |
| Numerical | root_tol | 1e-10 | Best-response fixed-point root tolerance |
| Numerical | root_maxfev | 80 | Root evaluation budget |
| Numerical | cluster_tol | 0.0001 | Distance for clustering discovered candidates |
| Numerical | selection_tie_tol | 1e-10 | Tolerance for selection ties |
| Numerical | global_audit_maxiter | 35 | DE iteration budget when local search fails |
| Numerical | global_audit_popsize | 8 | DE population multiplier |
| Numerical | global_audit_seed | 20260928 | Reproducible primary DE seed |
| Numerical | delta | 0.025 | Strict terminal-suppression threshold |
| Numerical | audit_subdivisions | 2 | Diagnostic policy grid is dx divided by this value |
| Numerical | offgrid_subdivisions | 2 | Uniform state-probe grid is dx divided by this value |
| Numerical | policy_mode | resolved | Current-state strategy interface |
