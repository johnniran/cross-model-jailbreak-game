Supplementary Table S3. State-grid, initialization, whole-policy diagnostic-resolution, and tolerance checks. Whole-policy resolution changes only the audit, not the stored primary continuation grid. Tolerance runs check every solver state and the realised path; broader state and whole-policy audits are not run for that auxiliary phase. Failed state-grid cases retain missing terminal outcomes.

| panel | case | setting | accepted | sampled_stage_pass | terminal_suppression | grid_max_regret | initial_policy_gain | path_max_regret | tested | TER |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| grid | grid_reference_0.1 | dx=0.1 | True | True | 0.154144 | 0 | 3.11078e-05 | 0 | NA | NA |
| grid | grid_reference_0.05 | dx=0.05 | True | True | 0.154326 | 3.17738e-05 | 0.000990927 | 1.26007e-06 | NA | NA |
| grid | grid_reference_0.025 | dx=0.025 | False | False | NA | NA | NA | NA | NA | NA |
| grid | grid_reference_0.0125 | dx=0.0125 | False | False | NA | NA | NA | NA | NA | NA |
| grid | grid_high_theta_low_lambda_0.1 | dx=0.1 | True | True | 0.154855 | 0 | 2.6148e-05 | 0 | NA | NA |
| grid | grid_high_theta_low_lambda_0.05 | dx=0.05 | True | True | 0.15453 | 6.37911e-09 | 5.36115e-06 | 0 | NA | NA |
| grid | grid_high_theta_low_lambda_0.025 | dx=0.025 | True | True | 0.154584 | 2.01011e-09 | 2.77457e-06 | 0 | NA | NA |
| grid | grid_high_theta_low_lambda_0.0125 | dx=0.0125 | True | True | 0.154521 | 5.02436e-10 | 1.51299e-06 | 0 | NA | NA |
| grid | grid_high_theta_high_lambda_0.1 | dx=0.1 | True | True | 0.411859 | 7.8297e-07 | 2.53677e-05 | 0 | NA | NA |
| grid | grid_high_theta_high_lambda_0.05 | dx=0.05 | True | True | 0.411394 | 5.34782e-06 | 2.43923e-05 | 0 | NA | NA |
| grid | grid_high_theta_high_lambda_0.025 | dx=0.025 | False | False | NA | NA | NA | NA | NA | NA |
| grid | grid_high_theta_high_lambda_0.0125 | dx=0.0125 | False | False | NA | NA | NA | NA | NA | NA |
| initialization | seeds_0.1 | seed=0.1 | True | True | 0.154323 | 2.85024e-05 | 0.000987121 | 9.08505e-06 | NA | NA |
| initialization | seeds_0.05 | seed=0.05 | True | True | 0.154326 | 3.17738e-05 | 0.000990927 | 1.26007e-06 | NA | NA |
| initialization | seeds_0.025 | seed=0.025 | True | True | 0.154326 | 3.17738e-05 | 0.000990927 | 1.26007e-06 | NA | NA |
| policy_refinement | policy_audit_resolved_1 | resolved; audit dx=0.05 | True | True | 0.154326 | 3.17738e-05 | 2.5594e-05 | 1.26007e-06 | NA | NA |
| policy_refinement | policy_audit_resolved_2 | resolved; audit dx=0.025 | True | True | 0.154326 | 3.17738e-05 | 0.000990927 | 1.26007e-06 | NA | NA |
| policy_refinement | policy_audit_resolved_4 | resolved; audit dx=0.0125 | True | True | 0.154326 | 3.17738e-05 | 0.00468936 | 1.26007e-06 | NA | NA |
| policy_refinement | policy_audit_interpolated_1 | interpolated; audit dx=0.05 | False | False | 0.154241 | 3.17738e-05 | 2.5594e-05 | 0.000413517 | NA | NA |
| policy_refinement | policy_audit_interpolated_2 | interpolated; audit dx=0.025 | False | False | 0.154241 | 3.17738e-05 | 8.90787e-05 | 0.000413517 | NA | NA |
| policy_refinement | policy_audit_interpolated_4 | interpolated; audit dx=0.0125 | False | False | 0.154241 | 3.17738e-05 | 0.00023631 | 0.000413517 | NA | NA |
| tolerance | 256 factorial cases | epsilon=5e-05 | 248 | not run | 0.0726121 | NA | NA | NA | 256 | 0.516129 |
| tolerance | 256 factorial cases | epsilon=0.0002 | 251 | not run | 0.0762285 | NA | NA | NA | 256 | 0.521912 |
| tolerance | 256 factorial cases | epsilon=0.0005 | 254 | not run | 0.0781827 | NA | NA | NA | 256 | 0.527559 |
