Table 1. Factorial outcomes conditional on grid and path acceptance. Terminal suppression is a theoretical state difference. The threshold is 0.025; the whole-policy test uses a diagnostic state spacing of 0.025 and is a separate approximate check. No confidence interval or empirical success rate is implied.

Table 2. Reference-case policy comparisons. Each fixed defence is a commitment policy with an analytically re-optimised attacker. Mutual myopic actions resolve a one-period game. The dynamic response to sampled myopic defence uses a fine-grid approximation with interpolated actions. Lower terminal state alone does not rank the defender's total payoff.

Table 3. One-at-a-time terminal-suppression ranges over the stated intervals. Each parameter retains its own scale; this is not a standardised or global importance ranking. Repeated reference tuples across dimensions are deliberate.

Figure 1. Reference dynamics. (a) Resolved attack and defence effort in each decision period. (b) Persistent state under the defended strategy and the no-defence benchmark, whose attacker re-optimises dynamically. State paths include the shared initial state. Both panel letters and both state lines are shown. The plotted paths do not establish a continuous-state equilibrium.

Figure 2. Mean terminal suppression by susceptibility and defence effectiveness, conditional on grid and path acceptance. Each cell shows its mean and accepted count out of 16. The two cost dimensions are averaged within the cell. Counts replace a separate coverage heatmap.

Figure 3. One-at-a-time terminal suppression around the reference case. Panels (a)–(h) vary initial state, susceptibility, attacker cost, defender cost, defence effectiveness, current-response weight, discount factor, and horizon, respectively. All panels use one vertical scale and ticks at the tested levels. The dotted line is the descriptive threshold. The susceptibility level 0.8 is unresolved: it is named in panel (b) and has no plotted outcome. Lines guide the eye across accepted tested levels. The small initial-state range is reported in Table 3; its apparent flatness at this common scale does not imply exact independence.

Supplementary Table S1. Assumed model parameters, sensitivity intervals, and primary numerical settings. No parameter is estimated from LLM observations. Full machine-readable settings, including the three deep-audit seeds and budgets, accompany every case.

Supplementary Table S2. Conditional factorial summaries. Each row averages over the other three factorial dimensions. The accepted count is reported with the conditional mean so missing cases are visible. These rows are descriptive and do not isolate a causal architectural effect.

Supplementary Table S3. State-grid, initialization, whole-policy diagnostic-resolution, and tolerance checks. Whole-policy resolution changes only the audit, not the stored primary continuation grid. Tolerance runs check every solver state and the realised path; broader state and whole-policy audits are not run for that auxiliary phase. Failed state-grid cases retain missing terminal outcomes.

Supplementary Table S4. Threshold, candidate-selection, functional-form, and unresolved-case checks. Selection means use the common cohort accepted under all five rules with the same expanded search profile. Each alternative functional form is compared with the primary model on its own matched accepted cohort. This is a targeted 36-case check per alternative, not a repetition of the full 256-case design. The failure residual is the primary search result; seeded audit records remain in the raw archive.

Supplementary Figure S1. Reference verification domains. (a) Maximum local stage regret over the solver grid and midpoint probes for the resolved primary strategy and the interpolated-action sensitivity strategy. (b) Initial whole-policy deviation gains at three diagnostic spacings with the primary continuation grid fixed at 0.05. The dotted gain line marks 0.0001. These approximate whole-policy checks are not a proof about unsampled states or a convergence study of the primary solver.
