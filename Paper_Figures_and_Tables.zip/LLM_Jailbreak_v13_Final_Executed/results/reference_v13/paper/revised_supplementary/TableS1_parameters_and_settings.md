Supplementary Table S1 Parameters and numerical settings

**a Model parameters**

| Parameter | Symbol | Reference | Tested values |
| --- | --- | --- | --- |
| Initial state | $x_{0}$ | 0.50 | 0.10, 0.30, 0.50, 0.70, 0.90 |
| Pair susceptibility | $\theta$ | 0.60 | 0.20, 0.40, 0.60, 0.80 |
| Attacker effort-cost coefficient | $\kappa_{A}$ | 0.50 | 0.25, 0.50, 1.00, 1.50 |
| Defender effort-cost coefficient | $\kappa_{D}$ | 0.50 | 0.25, 0.50, 1.00, 1.50 |
| Defence-effectiveness coefficient | $\lambda$ | 1.00 | 0.50, 1.00, 1.50, 2.00 |
| Current-response weight | $\rho$ | 0.50 | 0.25, 0.50, 0.75, 1.00 |
| Discount factor | $\gamma$ | 0.95 | 0.80, 0.90, 0.95, 1.00 |
| Number of decision periods | $T$ | 10 | 5, 10, 15, 20 |

**b Primary numerical and diagnostic settings**

| Setting | Value |
| --- | --- |
| Primary state-grid spacing | 0.05 |
| Stage-regret tolerance $\epsilon_{NE}$ | 0.0001 |
| Midpoint-probe spacing | 0.025 |
| Whole-policy diagnostic spacing | 0.025 |
| Initial whole-policy gain cutoff | 0.0001 |
| Descriptive terminal threshold $\epsilon_{x}$ | 0.025 |

Note. Parameter values are assumed scenario settings, not estimates from LLM experiments or optimal settings. The factorial design jointly varies $\theta$, $\lambda$, $\kappa_{A}$ and $\kappa_{D}$, giving $4^{4}=256$ configurations; other parameters remain at their reference values. The listed intervals are also used for one-at-a-time analysis. The primary model uses a rational response and quadratic defender state loss. Actions are continuous and re-solved at the current state. Midpoint and whole-policy checks are separate from primary grid-and-path acceptance. Full search settings and additional comparisons are retained in the reproducibility archive.
