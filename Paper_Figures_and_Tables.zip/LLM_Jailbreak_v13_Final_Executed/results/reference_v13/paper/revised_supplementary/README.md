# Revised manuscript supplementary tables

Use the three tables in this directory for the manuscript and the accompanying
three-page Word document for copying into Word. The paper-wide manuscript index
is `../MANUSCRIPT_OUTPUT_INDEX.json`.

- S1: parameters and key numerical settings.
- S2: state-grid refinement and re-solved whole-policy diagnostics.
- S3: alternative functional forms and five unresolved factorial cases.

The original four full audit tables remain unchanged in `../supplementary`.
They are retained because the unchanged export and verification scripts expect
those files and the original `../OUTPUT_INDEX.json`. They are reproducibility
records, not the current manuscript table selection. The supplementary figure
remains `../supplementary/FigureS1_verification_domains` in its existing formats.

`SELECTION_MAP.json` identifies the selected rows and numerical settings. CSVs
retain the source precision; Markdown and Word use rounded display values.
The full conditional factorial, threshold, selection, initialization and
tolerance comparisons remain available in the original audit tables and raw
phase outputs.

No solver, experiment, figure or stored numerical result was changed. Re-running
the original exporter produces its original four audit tables. Keep this revised
presentation directory when doing so; this selection does not require a code edit.

Manuscript cross-references: former S3 becomes S2; former S4 becomes S3.
Remove manuscript references to the former conditional-results S2.
