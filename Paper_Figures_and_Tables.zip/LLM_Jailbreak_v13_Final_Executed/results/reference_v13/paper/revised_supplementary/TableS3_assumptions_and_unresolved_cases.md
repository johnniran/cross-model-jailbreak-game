Supplementary Table S3 Assumption checks and unresolved cases

**a Alternative functional forms**

| Response / state loss | Tested | Alternative accepted | Matched cohort | Primary mean $\Delta x_{T}$ | Alternative mean $\Delta x_{T}$ | Alternative TER |
| --- | --- | --- | --- | --- | --- | --- |
| Exponential / quadratic | 36 | 33 | 33 | 0.155463 | 0.187990 | 66.67% |
| Rational / linear | 36 | 36 | 34 | 0.161253 | 0.179847 | 73.53% |

Note. The primary specification uses a rational response and quadratic defender state loss. Each alternative tests 36 targeted configurations. Means and threshold exceedance rates (TER) use cases accepted under both the primary and alternative specifications, giving matched cohorts of 33 and 34 cases. TER is the percentage with $\Delta x_{T}>0.025$. These checks do not repeat the full factorial design.

**b Unresolved primary factorial configurations**

| Case | $\theta$ | $\lambda$ | $\kappa_{A}$ | $\kappa_{D}$ | Stage | State | Best stage regret |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 196 | 0.80 | 0.50 | 0.50 | 0.25 | 2 | 0.35 | 0.00044371 |
| 213 | 0.80 | 1.00 | 0.50 | 0.50 | 4 | 0.20 | 0.00010085 |
| 214 | 0.80 | 1.00 | 0.50 | 1.00 | 2 | 0.35 | 0.00042795 |
| 230 | 0.80 | 1.50 | 0.50 | 1.00 | 2 | 0.35 | 0.00075700 |
| 231 | 0.80 | 1.50 | 0.50 | 1.50 | 2 | 0.05 | 0.00012602 |

Note. Case numbers refer to the archived identifiers factorial_196, factorial_213, factorial_214, factorial_230 and factorial_231. Each row reports the first unresolved stage and state and the best stage regret recorded by the primary search. All five exceed $\epsilon_{NE}=0.0001$. A search failure does not prove that an equilibrium does not exist. These configurations are excluded from suppression summaries, and their terminal outcomes remain missing. Additional seeded searches are retained in the reproducibility archive.
