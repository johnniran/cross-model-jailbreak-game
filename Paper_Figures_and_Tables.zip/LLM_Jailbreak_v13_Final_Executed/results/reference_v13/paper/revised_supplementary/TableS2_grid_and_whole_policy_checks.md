Supplementary Table S2 Grid and whole-policy checks

**a State-grid refinement**

| Scenario | Grid spacing | Primary criterion | $\Delta x_{T}$ | Maximum grid regret | Initial whole-policy gain |
| --- | --- | --- | --- | --- | --- |
| Reference | 0.1 | Pass | 0.154144 | 0 | $3.1108\times10^{-5}$ |
| Reference | 0.05 | Pass | 0.154326 | $3.1774\times10^{-5}$ | 0.000991 |
| Reference | 0.025 | Unresolved | — | — | — |
| Reference | 0.0125 | Unresolved | — | — | — |
| A | 0.1 | Pass | 0.154855 | 0 | $2.6148\times10^{-5}$ |
| A | 0.05 | Pass | 0.154530 | $6.3791\times10^{-9}$ | $5.3612\times10^{-6}$ |
| A | 0.025 | Pass | 0.154584 | $2.0101\times10^{-9}$ | $2.7746\times10^{-6}$ |
| A | 0.0125 | Pass | 0.154521 | $5.0244\times10^{-10}$ | $1.5130\times10^{-6}$ |
| B | 0.1 | Pass | 0.411859 | $7.8297\times10^{-7}$ | $2.5368\times10^{-5}$ |
| B | 0.05 | Pass | 0.411394 | $5.3478\times10^{-6}$ | $2.4392\times10^{-5}$ |
| B | 0.025 | Unresolved | — | — | — |
| B | 0.0125 | Unresolved | — | — | — |

Note. Scenario A uses $\theta=0.80$ and $\lambda=0.50$; scenario B uses $\theta=0.80$ and $\lambda=2.00$. Other parameters use reference values. A primary pass applies to solver-grid and realised-path stage regrets. A dash marks an unavailable result from an unresolved run. Terminal suppression is $\Delta x_{T}=x_{T}^{noD}-x_{T}^{def}$. Initial whole-policy gain is the larger estimated deviation gain of the two players at the initial state.

**b Whole-policy audit resolution at the reference setting**

| Audit spacing | Primary criterion | $\Delta x_{T}$ | Initial whole-policy gain | Gain cutoff |
| --- | --- | --- | --- | --- |
| 0.05 | Pass | 0.154326 | $2.5594\times10^{-5}$ | Pass |
| 0.025 | Pass | 0.154326 | 0.000991 | Fail |
| 0.0125 | Pass | 0.154326 | 0.004689 | Fail |

Note. Panel b retains the primary continuation grid at 0.05 and uses re-solved actions; only the audit spacing changes. The initial whole-policy cutoff is 0.0001. Gains are diagnostic estimates, not certified continuous-state error bounds. The failed gain checks and unresolved finer-grid runs limit the equilibrium interpretation and prevent a general numerical-convergence claim.
