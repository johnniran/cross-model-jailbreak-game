Supplementary Table S1. Assumed model parameters, tested values and key numerical settings. Values are scenario choices, not estimates from LLM observations.

Supplementary Table S2. State-grid refinement and initial whole-policy diagnostics. Primary grid-and-path passes are separate from whole-policy gain checks; unresolved finer-grid runs retain missing outcomes.

Supplementary Table S3. Alternative functional forms and unresolved primary factorial cases. Functional-form summaries use matched accepted cohorts. Search failures do not prove equilibrium non-existence.
